# STORY — culture c106 — Mason Ortega

## §1 ASSIGNMENT
- ANGLE (assigned by the editor — fixed): Jack London kitchens: Harborline Grill, Blue Lantern Bar, Green & Gold Tavern — the people who work the shift
- HOOK: Tomas Renteria, Podcast Host / Line Cook at Harborline Grill. 6 named workers at 2 named kitchens in Jack London on the ledger this cycle.
- AFFECTED CITIZENS: Tomas Renteria (POP-00744); Quynh Le (POP-00878); Jalen Hill (POP-00960); Bruce Wright (POP-00965); Yuki Ji (POP-00783); Guadalupe Lee (POP-00970); Mei-Lin Kang (POP-00835); Ileana Vasquez (POP-00718); Anna Baker (POP-00471)
- WHERE: Jack London
- SOURCE: output/beats/Business_Ledger.jsonl + Employment_Roster.jsonl @C106
- DESK APPROACH: Food & hospitality approach — kitchens as workplaces: this slice is one neighborhood's restaurants, cafes and bars from the ledger and the people on the roster who work in them. The people on this slice are real; the rest of the room is yours — the line on a Tuesday, the regulars, the walk-in, the tip jar. One kitchen, one shift, one true thing about the work. Not a review. Not multi-voice culture-desk average. Facts on this slice: the names, places, roles and numbers listed. Those are real; do not invent people or places. Everything else about this beat — what it looks like, who is there, what they want and hate — is yours to paint.

## §2 THE REPORTER'S PLAN (wake 1, their own voice)
I'm planning to focus on Tomas Renteria, the Podcast Host and Line Cook at Harborline Grill, as the central figure for this article. The angle will be the intersection of his dual roles and how they reflect the broader culture of Jack London's kitchens. I'll also touch on the dynamics of the kitchen shift, the regulars, and the tip jar, painting a vivid picture of the workplace atmosphere.
## §3 INTERVIEWS (wake 2 — real citizens, real quotes)
- Tomas Renteria (POP-00744): "Man, juggling the podcast and the line cook gig at Harborline? It's all about rhythm, you know? At the grill, it's fire and timing, making sure every plate's right. Then with the mic, it's about catching that same energy but with voices and stories instead of food. Both feed people, just different ways. Keeps me moving, keeps me connected to what's real in this neighborhood."
- Quynh Le (POP-00878): "Tomas? Yeah, he's got this energy about him—like he's always working on something bigger, even when he's just plating up orders. The podcast thing doesn't surprise me. He's the kind of guy who talks to everyone, remembers their stories. You can tell he's listening, not just waiting for his turn to speak. That's probably why it works—both the kitchen and the mic."
- Jalen Hill (POP-00960): "Tomas? Man keeps his head down on the line, does his job. I hear the podcast chatter sometimes when we're breaking down stations, but Harborline's not the kind of place where you bring that energy to work. We're all just trying to get through the rush."

## §4 THE ARTICLE (wake 3)
- draft: output/cron-compare/staged/culture_c106_mason-ortega_packet-v2_deepseek-deepseek-chat.staged.md
- disposition: staged
- rhea: PASS
- self-score footer: present
- tool use: none

