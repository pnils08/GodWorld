# The Rhythm Between the Grill and the Mic

In the back kitchen of Harborline Grill, Tomas Renteria flips a salmon fillet with the same practiced motion he might use to adjust a microphone level. The podcast host and line cook moves through his Wednesday dinner rush in a rhythm that seems to split his attention perfectly between sizzling protein plates and the stories he collects about this Jack London square neighborhood.

"Man, juggling the podcast and the line cook gig at Harborline? It's all about rhythm, you know?" Renteria says, checking the doneness of three medium-rare orders with a press of his tongs. "At the grill, it's fire and timing, making sure every plate's right. Then with the mic, it's about catching that same energy but with voices and stories instead of food."

Around him, the Harborline line cooks navigate the tight kitchen space—Quynh Le layering roasted vegetables with precision, Jalen Hill silently refilling the fry station as the ticket printer spits another wave of orders.

"Tomas? Yeah, he's got this energy about him—like he's always working on something bigger, even when he's just plating up orders," says Le during a rare lull, wiping her knife down. "You can tell he's listening, not just waiting for his turn to speak."

Hill offers a different take between loading sheet trays into the washer: "Man keeps his head down on the line, does his job. I hear the podcast chatter sometimes when we're breaking down stations, but Harborline's not the kind of place where you bring that energy to work. We're all just trying to get through the rush."

The duality shows in the details—how Renteria's podcast notes sometimes appear between prep lists on the stainless steel counter, how the regulars at the bar seem to lean in when he emerges from the kitchen, still in his apron, to record a quick vox pop during his smoke break.

But the real crossover happens after close, when Renteria’s colleagues become his first audience, their off-shift beers turning into impromptu focus groups. They're the ones who remind him that both jobs—feeding bodies and feeding minds—come down to the same question: Did you leave them satisfied?

## INTAKE
NAMES: Tomas Renteria | quoted-source
NAMES: Quynh Le | quoted-source
NAMES: Jalen Hill | mentioned
STORYLINE: jack-london-tomas-renteria-story-signal | opened
HOOD: Jack London
CLAIM: Man, juggling the podcast and the line cook gig at Harborline? It's all about rhythm, you know? At the grill, it's fire and timing, making sure every plate's right. Then with the mic, it's about catching that same energy but with voices and stories instead of food. Both feed people, just different ways. Keeps me moving, keeps me connected to what's real in this neighborhood. | citizenVoice PRESS Tomas Renteria
<!-- SELF-SCORE: question-answered=no; affected-citizen-shown=yes; sim-state-cited=yes -->
