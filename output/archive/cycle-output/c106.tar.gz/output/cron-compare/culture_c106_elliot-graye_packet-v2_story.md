# STORY — culture c106 — Elliot Graye

## §1 ASSIGNMENT
- ANGLE (assigned by the editor — fixed): crisis response at Temple Beth Or (Rockridge) — the week in faith, and Bay Pure Land Buddhist Temple in focus
- HOOK: Temple Beth Or (Rockridge), C104: congregation opens doors for community support
- AFFECTED CITIZENS: Kenji Tanaka (POP-00763); Naomi Sterling (POP-00759); Eleanor Bishop (POP-00768); Robert Jaston (POP-00758); Idris Karim (POP-00761); Eunice Marston (POP-00753); Yael Bauer (POP-00760); Antoine Vermeer (POP-00755)
- WHERE: Chinatown
- SOURCE: output/beats/Faith_Organizations.jsonl "Bay Pure Land Buddhist Temple"
- DESK APPROACH: Faith and quiet-work approach: this slice is the week's faith events on the record — services, holy days, outreach, crisis response, with the congregations and neighborhoods named — plus one congregation in focus and the community programs around it. Dignity, not doctrine wars. The events, institutions and people are real; the sanctuary on a weeknight, the basement kitchen, the Tuesday meeting are yours. Facts on this slice: the names, places, roles and numbers listed. Those are real; do not invent people or places. Everything else about this beat — what it looks like, who is there, what they want and hate — is yours to paint.

## §2 THE REPORTER'S PLAN (wake 1, their own voice)
I'm looking into the recent surge in faith events across Oakland, particularly the crisis response efforts by various congregations. I want to explore how these events are bringing communities together and providing support during difficult times.
## §3 INTERVIEWS (wake 2 — real citizens, real quotes)
- Kenji Tanaka (POP-00763): "I've seen the Bay Pure Land Buddhist Temple as a place of peace and comfort in our community. As a faith leader, I appreciate the importance of having such a space in Chinatown."
- Naomi Sterling (POP-00759): "I don't really know much about the Bay Pure Land Buddhist Temple, but I've been focused on our own community's response to the recent crisis, and I've seen how other faith organizations have come together to support each other."

## §4 THE ARTICLE (wake 3)
- draft: output/cron-compare/staged/culture_c106_elliot-graye_packet-v2_deepseek-deepseek-chat.staged.md
- disposition: staged
- rhea: PASS
- self-score footer: present
- tool use: none

