# Downtown, Overcast, Nobody's Name on It

Merkin Jumper's been standing outside SpeedyBurger on his lunch break for eleven minutes now, folder under his arm, watching the line move fast like it always does. He's a caseworker. He notices things for a living. "I've seen the way the neighborhood is, you know," he tells me, still watching, "the towers staying lit late and people always rushing to and from places like Telegraph Presbyterian and SpeedyBurger. It feels like there's a lot of activity, but at the same time, I've heard people talking about how Downtown is decaying." He shrugs, folder still under his arm. "As someone who works with the community, I feel like I'm making a difference, but I also wish there were more initiatives to address the issues we're facing."

Wish. That's the word doing the work. Not waiting on. Not was told. Wish — like a birthday candle, not a budget line.

Here's what the record actually says, because Jumper's gut and the numbers agree for once: Downtown's sentiment reading dropped four-tenths of a point and now sits at 0.41 — eighth out of twenty-two neighborhoods, technically above the city's own median of 0.36, so don't let anybody tell you this is the worst block in town. It isn't. But retail vitality fell nearly three full points to 9.55, and housing pressure jumped a full point to 3, worse than eighteen of twenty-two neighborhoods in this city. Three metrics, three directions, all bad, all landing on the same eight or nine downtown blocks in the same stretch. And when I went looking for the initiative, the task force, the office, the anything with a name on it that's supposed to be sitting on this fire — there's nothing. No matching program. No mitigator. Nobody's desk.

I found Celeste Moon near the towers that stay lit past when anybody's working in them, and she hadn't heard about any of it. "I haven't really thought about it," she said, "but I did hear Downtown was packed last night. That's all I know." Packed. Lit up. And decaying underneath it — those aren't contradictions, they're the same neighborhood wearing two faces depending which number you trust.

Then there's Eunice Marston, who runs faith work out of her building and watches her congregation stream past SpeedyBurger every week like clockwork. "I haven't really seen any significant changes or initiatives that address the concerns about Downtown decay," she told me, "but I do see people from my community, like those coming out of Telegraph Presbyterian, going about their daily lives. As a faith leader, I try to stay focused on the people and their needs, rather than getting caught up in the broader issues." That's a pastor telling me, politely, that the city hasn't given her congregation anything to point at either. She's not chasing the broader issues because nobody handed her a broader issue to chase — just a block getting quietly worse under lit windows.

Three people, three vantage points, same blank space where an answer should be. A caseworker who wishes there were more programs. A singer who heard it was packed and left it there. A pastor keeping her eyes on people because the paperwork isn't giving her anything else to look at.

Somebody at City Hall owns a map with Downtown's numbers moving the wrong direction on three separate lines at once. Nobody's initiative owns the fix. So who's supposed to be reading this map, and why hasn't anyone told Merkin Jumper, Eunice Marston, or the rest of us what they're seeing?

-- Jax Caldera | tipline: JAX-TIPS

## INTAKE
NAMES: Celeste Moon | mentioned
NAMES: Merkin Jumper | quoted-source
NAMES: Eunice Marston | quoted-source
STORYLINE: downtown-merkin-jumper-undocked | advanced
HOOD: Downtown
CLAIM: I haven't really seen any significant changes or initiatives that address the concerns about Downtown decay, but I do see people from my community, like those coming out of Telegraph Presbyterian, going about their daily lives. As a faith leader, I try to stay focused on the people and their needs, rather than getting caught up in the broader issues. | citizenVoice PRESS Eunice Marston
<!-- SELF-SCORE: question-answered=no; affected-citizen-shown=yes; sim-state-cited=yes -->
