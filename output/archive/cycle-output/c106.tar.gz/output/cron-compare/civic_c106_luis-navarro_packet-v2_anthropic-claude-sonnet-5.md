## Council Talk, Neighborhood Math

Elio Perez has the rag out before the lunch rush even starts. West Oakland comes in loud through the kitchen door — dish pit running, someone yelling for extra lemons — and he's wiping the same four-top for the third time because his hands need something to do while he talks.

"I feel like the council talks a lot about accountability," he says, setting down a stack of menus, "but I don't see much action that actually closes the gap for people like me and my neighbors."

He doesn't name a meeting. He doesn't name a vote. He names a feeling that's been sitting on him long enough to become a sentence he's ready to say to a reporter between tables.

Across town, in Rockridge, Depak Ying is doing the same job at a different address — folding napkins into the kind of triangles that look sharp on a table setting, waiting for the door to open. He's heard the same thing Elio has, secondhand, the way these things travel between servers who don't know each other but know the same shift.

"I've heard people talking about the council not stepping up," he says, "and it feels like there's a disconnect — like they're not hearing what's happening in the neighborhoods. It's frustrating because we're all just trying to make things work here."

Two servers, two neighborhoods, one word showing up in both mouths without either of them coordinating it: disconnect.

Here's what I can put on the page and what I can't.

What's confirmed: the city's own accounting flagged a civic gap this cycle — a distance between what accountability sounds like from the dais and what it does on the ground. That's not my read of the room. That's the finding itself. And paired with it: no civic initiative currently on the books answers that gap. Not a stalled one. Not a delayed one. None.

What isn't confirmed, and what I'm not going to pretend I know: which office owns that gap. Which councilmember, if any, has been asked and gone quiet. Whether a request went out and got nothing back, or whether nobody's filed the request yet. I don't have a name to put pressure on, and I'm not inventing one to make this piece feel more finished than it is.

That's the uncomfortable part of this kind of story. Elio and Depak aren't wrong about what they feel. The gap they're describing is real enough that it shows up in the city's own instruments, not just in their frustration. But feeling a disconnect and being able to point to who's responsible for closing it are two different things, and right now only one of those exists on the record.

So the question isn't rhetorical, and it isn't mine to answer for them: if the city can see the gap clearly enough to log it, who exactly is supposed to be the one closing it — and how long does a table full of servers in two different neighborhoods have to keep saying the same sentence before somebody with a title says it back?

## INTAKE
NAMES: Elio Perez | quoted-source
NAMES: Depak Ying | mentioned
STORYLINE: city-elio-perez-anomaly | advanced
CLAIM: I feel like the council talks a lot about accountability, but I don’t see much action that actually closes the gap for people like me and my neighbors. | citizenVoice PRESS Elio Perez
<!-- SELF-SCORE: question-answered=no; affected-citizen-shown=yes; sim-state-cited=yes -->
