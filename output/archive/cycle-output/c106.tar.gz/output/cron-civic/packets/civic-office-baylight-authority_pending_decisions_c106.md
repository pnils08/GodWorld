# Pending Decisions — Baylight Authority Director Keisha Ramos — Cycle 106


## What you run
Baylight District — Final Council Vote — Budget: $2.1B.

## City This Cycle
- **Baylight District** — mood clearly upbeat; street trade struggling; crime low.

## What you did last cycle (the public remembers)
With council authorization secured, the Baylight Authority is mobilizing the Phase II development team to begin environmental remediation and early construction staging. Our focus remains delivering the project on time and within the allocated budget while meeting all infrastructure commitments.

## Directive from Mara Vance, City Planning Director — answer it; silence is a choice you will be charged for
## Keisha Ramos — Baylight Authority Director

- **Address:** Deliver the Phase II master development contract terms and bid finalization calendar ahead of the scheduled C107 contract signing.
- **Why:** Council approved the Phase II developer bid in C105 (INIT-006), requiring administrative preparation of binding contract terms and environmental remediation schedules in C106.
- **Acceptance:** A filed Phase II contract execution timeline including infrastructure obligations and remediation milestones.
- **Silence consequence:** Contract finalization delays push master developer signing past the C107 tracker deadline.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [Baylight District Community Impact] Keisha Ramos — Elmhurst residents will have a direct line to the construction team starting tomorrow.
2. stated: [Baylight District Phase II Mobilization] Keisha Ramos — Thirty-five thousand seats start with clean ground — remediation crews mobilize next cycle.
3. stated: [Baylight District Phase II Mobilization] Keisha Ramos — With the vote secured, we're moving dirt within two cycles — Baylight's future starts now.
4. datawake: The Baylight Authority has completed its Phase II bid evaluation—three qualified consortiums advance with proposals that meet our exacting standards. We await the council's final vote to move forward with the team that will deliver this landmark project.
5. stated: [Baylight District Phase II Shortlist] Keisha Ramos — Every dollar of the $2.1B budget will be accounted for—starting with these scoring sheets.
6. datawake: The Baylight Authority has completed the Phase II shortlist evaluation, reducing four qualified consortiums to three finalists. Each team submitted a detailed proposal demonstrating their capability to deliver the project on time and within budget. The final selection will be made within the next two cycles after thorough review of the final proposals. The winning team will be tasked with executing the larg

No district pack on disk for this office this cycle.

## DECISION 1 — Baylight District — Final Council Vote — engine-flagged

Where it stands: C105: Final council vote approved Phase II bid; construction planning phase begins.
Budget: $2.1B.
On the calendar: Bid finalization and contract signing.
The engine's own review flags this: Jack London, Downtown: improvement flagged at low severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Your constituents this cycle — crisis and credit

Crisis: **Baylight District** — mood clearly upbeat, street trade struggling, crime low. The people there are living this cycle whether City Hall speaks or not.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for Baylight District?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
