PREWRITE:
- Reporter: Sgt. Rachel Torres  
- BagModes: [Pattern Analysis, Classification Gap]  
- AnchorFacts: [Downtown leads in incidents (14), 15% clearance rate, 9.3 min response time]  
- Claim: Downtown's high-volume, low-outcome incident pattern raises questions about response resource allocation and classification drift.  
- MissingData: [Invented officer names, unsupported crime wave claims, procedural speculation]  
- PriorFiling: [downtown-jessie-hess-season-feel thread open]  

---

**Downtown's Dispatch Fatigue Shows in the Numbers**  

Jessie Hess leans against a lamppost on 14th Street, watching a patrol car dart past with lights flashing but no siren. "See? Again," she says as it vanishes around the corner toward Broadway. "I clocked three calls today where they took the report and rolled out before witnesses finished talking."  

Downtown logged 14 incidents this cycle—more than any other neighborhood—with a 15% clearance rate that trails the city average. Response times clocked at 9.3 minutes, faster than East Oakland's 13.8-minute wait but leaving little room for thorough investigation. The pattern repeats: 10 of the 14 calls closed as "information only" reports, a classification that signals no immediate threat but often masks recurring quality-of-life complaints.  

Vanessa Tran-Muñoz, the sole OARI response coordinator assigned Downtown, juggles overlapping dispatches from her makeshift office near Frank Ogawa Plaza. The alternative response program wasn't designed for this volume—most of her case load involves mediation and follow-ups that traditional patrols lack time to pursue.  

Property crimes accounted for 58% of the Downtown index, though Hess notes blurred lines: "Last week's 'theft' was someone smashing car windows just to sleep inside when the shelters were full. Cops called it vandalism, social workers called it survival, and the report wound up in limbo."  

The unanswered question lingers: When incidents outpace clearances five-to-one, what thresholds trigger resource reallocation?

## INTAKE
NAMES: Vanessa Tran-Muñoz | subject
NAMES: Jessie Hess | mentioned
STORYLINE: downtown-jessie-hess-season-feel | advanced
HOOD: Downtown
CLAIM: I see the cops scrambling all the time down here - always in a hurry, never sticking around long enough to really fix anything. Vanessa's doing her best, but one person can't handle this whole neighborhood. | citizenVoice PRESS Jessie Hess
<!-- SELF-SCORE: question-answered=no; affected-citizen-shown=yes; sim-state-cited=yes -->
