# STORY — civic c106 — Carmen Delaine

## §1 ASSIGNMENT
- ANGLE (assigned by the editor — fixed): West Oakland Stabilization Fund | Status passed | phase disbursement-active
- HOOK: The civic record identifies a decision, initiative, or clock that needs a clear accounting.
- WHERE: West Oakland
- SOURCE: Initiative_Tracker (InitiativeID INIT-001); snapshot: engine_audit_c106.json snapshots.Initiative_Tracker
- DESK APPROACH: Civic-ledger approach: follow the supplied initiative, vote, or decision through money, clocks, and responsible offices. One record-backed civic claim; not a press release or multi-voice roundup.

## §2 THE REPORTER'S PLAN (wake 1, their own voice)
I’m chasing the West Oakland Stabilization Fund as it enters the disbursement phase. My focus is on tracking the money—where it’s going, who’s responsible for allocating it, and whether the promises made are being kept. I’ll start by talking to people directly impacted in West Oakland, like Elio Perez, Daniel Cloak, Irene Fay, and Darius Clark, to see if they’ve felt any tangible effects yet. I’m also keeping an eye on the civic record to ensure transparency and accountability.
## §3 INTERVIEWS (wake 2 — real citizens, real quotes)
- Elio Perez (POP-00201): "I’ve heard people talking about the Stabilization Fund at work and on the block—everyone wants to know where the money’s going and if it’s really helping the neighborhood."
- Daniel Cloak (POP-00722): "I’ve heard folks talking about the Stabilization Fund at the bakery, but it’s hard to tell where the money’s really going—it feels like we’re waiting for something solid to show up in the neighborhood."
- Darius Clark (POP-00961): "I heard folks at the bakery talking about that fund, but honestly, I don't know much about where the money's going. Just hoping it helps the neighborhood."

## §4 THE ARTICLE (wake 3)
- draft: output/cron-compare/staged/civic_c106_carmen-delaine_packet-v2_deepseek-deepseek-chat.staged.md
- disposition: staged
- rhea: PASS
- self-score footer: present
- tool use: none

