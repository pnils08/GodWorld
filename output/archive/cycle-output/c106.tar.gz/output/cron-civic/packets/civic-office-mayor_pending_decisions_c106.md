# Pending Decisions — Mayor Avery Santana — Cycle 106

Your approval stands at 64 — down 5 since last cycle.

## City This Cycle
The city stands at about 390,304 people; nearly everyone who wants work has it and the economy reads stable. The streets feel game this cycle.

**Evening texture:**
- **Famous people spotted:** Derek Obi, Jade Orion, Arturo Ramos
- **Restaurants:** **Eastlake Kitchen** (Eastlake), **Port Grind** (Grand Lake)
- **Fast food:** **SpeedyBurger** (Downtown)
- **Nightlife:** **Lakeside Whisper Bar** (Lake Merritt). Volume 4, vibe game-night, movement restricted. Weather impact 1.05.
- **City events:** West Oakland Neighborhood Stabilization Panel, Fruitvale Emergency Town Briefing, Lake Merritt Open-Air Book Market
- **Evening media TV:** **Crisis Desk**, **Slow Evenings**, **A's Prospect Report**, **The Julio Valencia (CL) Interview**
- **Evening media movies:** **Snowlight**, **Franchise**
- **Sports broadcast:** Oakland Sports Tonight - Playoff Special
- **Streaming trend:** breaking-news loop
- **Food trend:** Playoff tension dining - sports bar surge

**What happened around town:**
**Low-severity:**
- **HEALTH — crisis-spike — Laurel:** HEALTH event (impactScore 5)
- **GENERAL — texture — (no neighborhood):** flash choir
- **CIVIC — texture — (no neighborhood):** neighborhood grievance
- **FAITH — holy_day — Downtown:** Telegraph Presbyterian Fellowship observes Epiphany
- **FAITH — holy_day — Lake Merritt:** Cathedral of the Living Word observes Epiphany
- **FAITH — holy_day — Fruitvale:** St. Esperanza Parish observes Epiphany
- **FAITH — community_program — Downtown:** Telegraph Presbyterian Fellowship: job training workshop begins new session
- **FAITH — community_program — East Oakland:** Foothill Baptist Tabernacle: community health fair hosted

**Where the city is hurting (this cycle's worst signals):**
- Downtown: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
- Rockridge: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
- Grand Lake: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
- West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.

## Directive from Mara Vance, City Planning Director — answer it; silence is a choice you will be charged for
## Avery Santana — Mayor

- **Address:** Convene the Youth Apprenticeship Pipeline (INIT-007) public town hall and certify zero remaining backlog cases across municipal partner agencies.
- **Why:** Administrative orders issued in C105 established C106 as the deadline for clearing the intake backlog and conducting the public town hall, amid a 5-point drop in executive approval (64 in C106).
- **Acceptance:** Official certification of backlog clearance and a published town hall transcript or outcomes summary.
- **Silence consequence:** Failure to verify intake processing leaves applicants stalled and unresolved oversight questions for the administration.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [District Crisis and Credit — San Antonio and Temescal] Avery Santana — Temescal's mood is up because we built something there—San Antonio's next if we keep delivering.
2. stated: [West Oakland Stabilization Fund Month-Seven Disbursement] Avery Santana — Month seven means another round of families staying in their homes instead of getting pushed out—and we're not stopping at the district line.
3. stated: [Baylight District Phase II Bid Final Council Vote] Avery Santana — This is Oakland's future being built—by Oaklanders, for Oaklanders, and nobody's taking that from us.
4. stated: [Temescal Community Health Center Interior Framing and Inspections] Avery Santana — Somebody's work is paying off in Temescal—let's name whose: the construction crews hitting schedule, the community that demanded this, and the city that delivered.
5. stated: [Fruitvale Transit Hub Phase II Design-Phase Kickoff] Avery Santana — Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project, and their protection is non-negotiable.
6. stated: [Oakland Alternative Response Initiative Emergency East Oakland Expansion] Avery Santana — When three districts flash incoherence at once, we don't wait for the next budget cycle—we move.

Latest district pack on disk: output/cron-civic/packs/MAYOR-01_c106.json
This week's lever from that pack: Month-seven disbursement review

## DECISION 1 — West Oakland Stabilization Fund — action due this cycle

Where it stands: C105: Month-six disbursement batch approved (12 households); canvass launched for slipping blocks.
Budget: $28M.
On the calendar: Month-seven disbursement review — due THIS cycle.
The engine's own review flags this: West Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Oakland Alternative Response Initiative — engine-flagged

Where it stands: C105: District 1 expansion launched; monthly reporting and audit framework in place.
Budget: $12.5M.
On the calendar: First expansion-district evaluation.
The engine's own review flags this: West Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: Fruitvale: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: East Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
The engine's own review flags this: West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 3 — Fruitvale Transit Hub Phase II — Visioning — action due this cycle

Where it stands: C105: First visioning session conducted; feedback incorporated into design phase.
Budget: $230M.
On the calendar: Design-phase kickoff — due THIS cycle.
The engine's own review flags this: Fruitvale: improvement flagged at low severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 4 — Temescal Community Health Center — action due this cycle

Where it stands: C105: Structural frame completed ahead of schedule, MEP rough-ins advancing with second shift
Budget: $45M.
On the calendar: Interior wall framing and utility inspections — due THIS cycle.
The engine's own review flags this: Temescal: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 5 — Baylight District — Final Council Vote — engine-flagged

Where it stands: C105: Final council vote approved Phase II bid; construction planning phase begins.
Budget: $2.1B.
On the calendar: Bid finalization and contract signing.
The engine's own review flags this: Jack London, Downtown: improvement flagged at low severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 6 — Oakland Youth Apprenticeship Pipeline — action due this cycle

Where it stands: C105: Administrative order issued to clear backlog; intake processing targets mandated across agencies.
Budget: $12.5M.
On the calendar: Backlog processing completion + town hall — due THIS cycle.
The engine's own review flags this: West Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: Fruitvale: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: East Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
The engine's own review flags this: West Oakland, East Oakland, Fruitvale: improvement flagged at low severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 7 — The city's people this cycle — crisis and credit

Crisis: **San Antonio** — mood clearly upbeat, street trade slow, crime low. The people there are living this cycle whether City Hall speaks or not.
Success: **Temescal** — mood clearly upbeat, street trade busy. Somebody's work is paying off; say whose, or someone else will claim it.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of the city this cycle: who answers for San Antonio, and who gets the credit in Temescal?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.
