# Pending Decisions — OARI Program Director Vanessa Tran-Muñoz — Cycle 106


## What you run
Oakland Alternative Response Initiative — Budget: $12.5M.

## City This Cycle
- **West Oakland** — mood clearly upbeat; street trade slow; crime low.
- **Fruitvale** — mood clearly upbeat; street trade steady; crime low; St. Esperanza Parish observes Epiphany; the mood there has slipped since last cycle.
- **East Oakland** — mood clearly upbeat; street trade slow; crime low; Foothill Baptist Tabernacle: community health fair hosted; the mood there has slipped since last cycle.

## What you did last cycle (the public remembers)
Executed the District 1 operational launch for OARI, deploying bilingual crisis response teams across West Oakland with evening and weekend coverage matched to behavioral health call patterns. Published shift deployment thresholds addressing elevated CrimeIndex levels in expansion districts while finalizing D3 and D5 launch timelines based on D1 operational data.

## Directive from Mara Vance, City Planning Director — answer it; silence is a choice you will be charged for
## Vanessa Tran-Muñoz — OARI Program Director

- **Address:** Publish the District 1 initial operational assessment and deploy targeted shift protocols responding to persistent CrimeIndex spikes in West Oakland (1.10), Fruitvale (1.00), and East Oakland (1.11).
- **Why:** Engine audits flag high-severity incoherence between active INIT-002 operations and elevated crime indices across expansion corridors, gating the C107 expansion-district evaluation.
- **Acceptance:** An operational data report detailing D1 call diversion rates and responder shift coverage in West Oakland, Fruitvale, and East Oakland.
- **Silence consequence:** Unaddressed response gaps undermine public confidence and compromise the C107 expansion evaluation.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [District 1 Expansion Evaluation] Vanessa Tran-Muñoz — When we meet crisis with care instead of cuffs, our communities get safer faster.
2. datawake: West Oakland's first expansion-month evaluation shows our teams meeting crisis with care exactly where it's needed most—bilingual responders, evening and weekend coverage, and protocols built with community input are proving that crisis response can be both compassionate and effective. Fruitvale and D5 implementations will build on this evidence-based model.
3. stated: [East Oakland success attribution] Vanessa Tran-Muñoz — East Oakland's steady pulse this cycle didn't happen by accident—it's the result of neighbors looking out for neighbors, and a city that finally started listening.
4. stated: [District 1 OARI expansion deployment] Vanessa Tran-Muñoz — Crisis doesn't clock out at five, and neither do we—our West Oakland teams are live now, meeting people where they are with the language they speak and the hours they need.
5. datawake: West Oakland's launch meets crisis with care exactly where it's needed most—our teams are now live in District 1 with bilingual responders covering evening and weekend hours to match when behavioral health calls peak in this community. Fruitvale and D5 implementations will follow this evidence-based deployment model. | action: Finalizing D3 and D5 launch timelines based on D1's operational data | signal: 12
6. stated: [West Oakland coverage] Vanessa Tran-Muñoz — Nighttime crisis calls need the same compassionate response as daytime ones—that's why our West Oakland team now runs until midnight.

Latest district pack on disk: output/cron-civic/packs/PROJ-OARI_c106.json
This week's lever from that pack: First expansion-district evaluation

## DECISION 1 — Oakland Alternative Response Initiative — engine-flagged

Where it stands: C105: District 1 expansion launched; monthly reporting and audit framework in place.
Budget: $12.5M.
On the calendar: First expansion-district evaluation.
The engine's own review flags this: West Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: Fruitvale: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: East Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
The engine's own review flags this: West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Your constituents this cycle — crisis and credit

Crisis: **East Oakland** — mood clearly upbeat, street trade slow, crime low. The people there are living this cycle whether City Hall speaks or not.
Success: **Fruitvale** — mood clearly upbeat, street trade steady. Somebody's work is paying off; say whose, or someone else will claim it.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for East Oakland, and who gets the credit in Fruitvale?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
