# Pending Decisions — Health Center Project Director Bobby Chen-Ramirez — Cycle 103


## City This Cycle
- **Temescal** — mood clearly upbeat; street trade busy; crime low.

## Directive from Mara Vance, City Planning Director — answer it; silence is a choice you will be charged for
## Bobby Chen-Ramirez — Health Center Project Director

- **Address:** Deliver the formal resolution of the HCAI first-comments window and declare Phase 1 of the Temescal Community Health Center (INIT-005) closed.
- **Why:** C103 requires resolution of the state-level HCAI comments to lock in the accelerated construction timeline and double shifts implemented in C102.
- **Acceptance:** Submission of the HCAI sign-off sheet and a confirmed completion date for excavation and caisson drilling.
- **Silence consequence:** High-intensity double shifts run the risk of structural and budgetary penalties without HCAI clearance.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [Temescal engagement] Bobby Chen-Ramirez — The pharmacist at 47th & Telegraph gets more questions about our crane schedule than I do. Starting next week, his bulletin board gets daily progress photos.
2. stated: [HCAI resolution] Bobby Chen-Ramirez — HCAI stamped Sheet S-7.3 at 4:37 PM yesterday—that's the last structural note resolved. Caisson drilling finishes Thursday, three days ahead of schedule.
3. stated: [hcai_status] Bobby Chen-Ramirez — HCAI's first-comments window opens next cycle as planned. Their reviewer confirmed our seismic submittals meet OSHPD-3 requirements—no showstoppers.
4. stated: [construction_acceleration] Bobby Chen-Ramirez — We're running two crews now—one at dawn, one at dusk—but I won't sign off on concrete until every caisson meets OSHPD-3 specs. Temescal deserves a building that lasts.
5. datawake: We're moving earth to move medicine — site clearing done, excavation two-thirds complete, caisson drilling underway. Not fast, but steady. The dirt tells the story. | action: Inspecting caisson #7 with the geotech engineer and contractor foreman — depth, diameter, rebar placement per spec. | signal: 68% excavation complete

Latest district pack on disk: output/cron-civic/packs/PROJ-HEALTHCTR_c103.json
This week's lever from that pack: HCAI first-comments window resolution and Phase 1 close

## DECISION 1 — Temescal Community Health Center — action due this cycle

Where it stands: C102: Construction timeline accelerated; double shifts ordered for caisson drilling and excavation.
On the calendar: HCAI first-comments window resolution and Phase 1 close — due THIS cycle.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Your constituents this cycle — crisis and credit

Crisis: **Temescal** — mood clearly upbeat, street trade busy, crime low. The people there are living this cycle whether City Hall speaks or not.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for Temescal?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S DECISIONS THIS CYCLE

- Oakland Youth Apprenticeship Pipeline — Recruitment and Intake Bottlenecks: approved — "Eighty-six applicants shouldn’t be stuck in paperwork. We’re cutting the red tape and getting these young people to work."
- West Oakland Stabilization Fund — Month-Five Disbursement: approved — "Forty-five families have their money. The next seven get theirs this week—no delays, no excuses."
- Oakland Alternative Response Initiative — D7 Community Satisfaction Survey: task_force_created — "Public safety isn’t just about response times—it’s about trust. We’re listening, and we’re acting."
- Fruitvale Transit Hub Phase II — Visioning Compliance Review: bureau_review_approved — "Fruitvale deserves a transit hub that works for the people who use it every day. We’re moving this forward."
- Temescal Community Health Center — HCAI First-Comments Resolution: phase_one_close_approved — "Temescal needs this health center now—not next year, not when the paperwork is perfect."
- Baylight District — Phase II Shortlist Publication: shortlist_published — "Baylight isn’t just a stadium—it’s the future of Oakland. We’re building it right."
- Neighborhood Coherence — West Oakland, Fruitvale, and East Oakland: task_force_announced — "When neighborhoods are hurting, we don’t look away—we build a plan."
- Celebrating Progress in Dimond and KONO: credit_attributed — "Dimond and KONO are proof that when we invest in neighborhoods, they thrive."

The Mayor has spoken. React in your own voice — support, oppose, or go your own way.

## MAYOR'S AGENDA THIS CYCLE

- Oakland Youth Apprenticeship Pipeline — Recruitment and Intake Adjustments: Directing OEWD to implement immediate intake adjustments for the Youth Apprenticeship Pipeline — "We can’t let bureaucracy stand in the way of opportunity for Oakland’s young people."
- West Oakland Stabilization Fund — Month-Five Disbursement Batch: Approving month-five disbursement batch for 8 households — "The families who qualified for this support shouldn’t have to wait another day."
- Oakland Alternative Response Initiative — D7 Community Satisfaction Survey: Directing OARI to expand community engagement in West Oakland, Fruitvale, and East Oakland — "Trust isn’t built in a day—it’s built through action, listening, and accountability."
- Fruitvale Transit Hub Phase II — Visioning Compliance Review: Directing Bureau of Planning to advance compliance review and schedule next visioning session — "Fruitvale deserves a transit hub that works for the people who use it every day—we’re not letting this stall."
- Temescal Community Health Center — HCAI First-Comments Resolution: Resolving HCAI first-comments window and closing Phase 1 — "Temescal needs this health center now—not next year, not when the paperwork is perfect."
- Baylight District — Phase II Shortlist Publication: Celebrating the publication of the Phase II shortlist — "Baylight isn’t just a stadium—it’s the future of Oakland, and we’re building it right."
- Neighborhood Coherence — KONO and Dimond: Acknowledging success in Dimond and committing to support KONO — "When neighborhoods thrive, Oakland thrives—and we’re investing in both."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
