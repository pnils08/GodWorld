# Pending Decisions — City Council District 3 Rose Delgado — Cycle 106

## Live roster status (whip-read off THIS, not memory)
- D1 Denise Carter (OPP) — ACTIVE. Approval 76 (down 5 since last cycle)
- D2 Leonard Tran (IND) — ACTIVE. Approval 52 (down 2 since last cycle)
- D3 Rose Delgado (OPP) — ACTIVE. Approval 71 (down 5 since last cycle)
- D4 Ramon Vega (IND) — ACTIVE. Approval 51 (down 1 since last cycle)
- D5 Janae Rivers (OPP) — ACTIVE. Approval 76 (down 4 since last cycle)
- D6 Elliott Crane (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D7 Warren Ashford (CRC) — ACTIVE. Approval 45 (down 1 since last cycle)
- D8 Nina Chen (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D9 Terrence Mobley (OPP) — ACTIVE. Approval 51 (down 1 since last cycle)
- Full council: 9 active of 9 → a majority is 5.
Your approval stands at 71 — down 5 since last cycle.

## City This Cycle
- **Fruitvale** — mood clearly upbeat; street trade steady; crime low; St. Esperanza Parish observes Epiphany; the mood there has slipped since last cycle.
- **San Antonio** — mood clearly upbeat; street trade slow; crime low.

## What you did last cycle (the public remembers)
Prioritizing community-adapted safety models, accelerating transit-to-economic pipelines, and naming Fruitvale's grassroots recovery. San Antonio's revival requires actionable credit, not abstract praise.

## Directive from Mara Vance, City Planning Director — answer it; silence is a choice you will be charged for
## Rose Delgado — City Council District 3

- **Address:** Coordinate with the Transit Hub planning team on Fruitvale small business protections and address persistent elevated crime (CrimeIndex 1.00).
- **Why:** With INIT-003 entering its design phase in C106 and D3 constituent approval dropping 5 points (71 in C106), local merchants require council advocacy on construction mitigations.
- **Acceptance:** A filed memorandum to the Transit Hub Planning Lead outlining merchant mitigation priorities for E. 12th Street and San Antonio.
- **Silence consequence:** Fruitvale small businesses risk unmitigated disruption during the Phase II design and pre-construction stages.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [Constituent credit and accountability] Rose Delgado — Fruitvale's comeback was built by diner owners and street teams. San Antonio's momentum? Still waiting on the investment I demanded.
2. stated: [Cross-district incoherence resolution] Rose Delgado — Fruitvale's success shouldn't clash with East Oakland's needs—but treating them as identical will fail both.
3. stated: [Youth Apprenticeship Pipeline backlog clearance and San Antonio allocation] Rose Delgado — We're not clearing paperwork—we're clearing pathways. San Antonio's street trade is slow despite upbeat mood; that gap needs bodies and paychecks, not optimism.
4. stated: [Oakland Alternative Response Initiative expansion to District 3] Rose Delgado — Safety isn't a template. Toby Lamont's street teams and Marisol Achebe's mutual aid networks have been holding Fruitvale together while we debated—now we resource them.
5. stated: [Fruitvale Transit Hub Phase II design-phase merchant protections] Rose Delgado — Transit infrastructure must seed storefront revival, not displace it. I want vendor protection covenants in writing before a single blueprint gets finalized.
6. stated: [District Recovery Credit] Rose Delgado — Fruitvale's comeback was built by diner owners and street teams. San Antonio's momentum? That's the result of deliberate, gritty investment.

No district pack on disk for this office this cycle.

## DECISION 1 — Oakland Alternative Response Initiative — engine-flagged

Where it stands: C105: District 1 expansion launched; monthly reporting and audit framework in place.
Budget: $12.5M.
On the calendar: First expansion-district evaluation.
The engine's own review flags this: West Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: Fruitvale: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: East Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
The engine's own review flags this: West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Fruitvale Transit Hub Phase II — Visioning — action due this cycle

Where it stands: C105: First visioning session conducted; feedback incorporated into design phase.
Budget: $230M.
On the calendar: Design-phase kickoff — due THIS cycle.
The engine's own review flags this: Fruitvale: improvement flagged at low severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 3 — Oakland Youth Apprenticeship Pipeline — action due this cycle

Where it stands: C105: Administrative order issued to clear backlog; intake processing targets mandated across agencies.
Budget: $12.5M.
On the calendar: Backlog processing completion + town hall — due THIS cycle.
The engine's own review flags this: West Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: Fruitvale: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: East Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
The engine's own review flags this: West Oakland, East Oakland, Fruitvale: improvement flagged at low severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 4 — Engine review HIGH: incoherence

West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.
No city program currently answers this. Make a move this cycle — silence is a choice you will be charged for.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 5 — Your constituents this cycle — crisis and credit

Crisis: **San Antonio** — mood clearly upbeat, street trade slow, crime low. The people there are living this cycle whether City Hall speaks or not.
Success: **Fruitvale** — mood clearly upbeat, street trade steady. Somebody's work is paying off; say whose, or someone else will claim it.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for San Antonio, and who gets the credit in Fruitvale?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
