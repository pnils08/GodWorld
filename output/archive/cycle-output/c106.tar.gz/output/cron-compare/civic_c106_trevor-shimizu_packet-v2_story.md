# STORY — civic c106 — Trevor Shimizu

## §1 ASSIGNMENT
- ANGLE (assigned by the editor — fixed): 12th St Oakland City Center ridership up 10,522 vs C105 | 18 stations on the record — the platforms and the people who run them
- HOOK: 12th St Oakland City Center moved up the most this cycle; 9 transit workers on the roster.
- AFFECTED CITIZENS: Joel Wren (POP-00218); Jerald Jensen (POP-00280); Coen Cartier (POP-00338); Daire Green (POP-00442); Ray Neal (POP-00448); Calvin Mwangi (POP-00573); Eleanor Rivera (POP-00617); Elena Soria-Dominguez (POP-00791); Ximena Mehta (POP-01039)
- SOURCE: output/beats/Transit_Metrics.jsonl Cycle 106
- DESK APPROACH: Transit approach: this slice is every station on the record this cycle, what moved against last cycle, and the transit workers on the roster. Dry, technical, timestamp and pattern — but it is a place with people in it. One system, one claim about what changed. Facts on this slice: the names, places, roles and numbers listed. Those are real; do not invent people or places. Everything else about this beat — what it looks like, who is there, what they want and hate — is yours to paint.

## §2 THE REPORTER'S PLAN (wake 1, their own voice)
I’m looking at the numbers—ridership is up across the board, especially at 12th St Oakland City Center. That’s the story, but the people behind it are what I want to dig into. Who’s keeping these trains running? Who’s dealing with the congestion on I-880 and Telegraph? I’ll start with Eleanor Rivera, the BART Station Manager. She’s got to have a pulse on what’s happening on the platforms.
## §3 INTERVIEWS (wake 2 — real citizens, real quotes)
- Eleanor Rivera (POP-00617): "You know, it's been noticeable at 12th Street - more people coming through, more hustle in the station. But what really sticks with me is how the team just... adjusts. No big announcements, just everyone doing their part to keep things moving smoothly. It's not glamorous work, but when you see that many more people relying on the system, you realize how much depends on those quiet efforts."
- Joel Wren (POP-00218): "You know, I've been seeing more folks hopping on the buses lately—especially down at 12th Street. It's good to see people out and about, trusting the system again. But what really gets me is the crew keeping those buses running. Those mechanics and drivers? They're the ones putting in the long hours to make sure everyone gets where they need to go. It's not just numbers—it's people showing up every day, grease under their nails, making it work."
- Jerald Jensen (POP-00280): "You know, I see it every morning when I'm wiping down the benches at 12th Street Station—more folks pouring in, more tired faces heading to work, more kids dragging backpacks. It's not just numbers to me. I'm the one mopping up after the rush. Those riders? They're why I show up. Somebody's gotta keep the place clean so people can keep moving."
- Coen Cartier (POP-00338): "I’ve seen more folks hopping on the buses lately, especially around 12th Street. It’s been busy, but it feels good to know we’re helping people get where they need to go. The team’s been working hard to keep things running smoothly, and it’s paying off."

## §4 THE ARTICLE (wake 3)
- draft: output/cron-compare/staged/civic_c106_trevor-shimizu_packet-v2_deepseek-deepseek-chat.staged.md
- disposition: staged
- rhea: PASS
- self-score footer: present
- tool use: none

