# The Rockridge Equation  

Simone Adesanya, principal of Rockridge’s top-ranked school, leans against the doorway of her office, watching the hallway fill with chatter as the final bell rings. “You know, what makes Rockridge schools special isn’t any one thing you can point to,” she says, her voice steady. “It’s how this community wraps itself around these kids.”  

The numbers tell part of the story: a school quality index of 9, graduation rates at 95%, and 78% of students college-ready. But the real texture lies in the hallways—teachers who’ve been here for decades, parents who show up not just for their own child but for the whole class, and an unspoken expectation that everyone is in this together. One of those parents, Mei Wong, works with kids in the after-school program. “It’s not just about funding—though that’s part of it—it’s the collective effort,” she says.  

Rick Dillon, an eighth-grader, puts it more simply: “We just do our homework and play baseball after.”  

What holds Rockridge together isn’t a mystery, but neither is it easily replicated. The Bay Conservation Alliance pitches in, businesses contribute, and the community rallies around its 223 students. The question now is whether this model can inspire other neighborhoods striving to close the gap.

## INTAKE
NAMES: Mei Wong | mentioned
NAMES: Rick Dillon | mentioned
NAMES: Simone Adesanya | quoted-source
STORYLINE: rockridge-mei-wong-beat-schools | opened
HOOD: Rockridge
CLAIM: As someone who works with kids in Rockridge, I’ve seen firsthand how much the community invests in education. It’s not just about funding—though that’s part of it—it’s the collective effort. Parents, teachers, and even local businesses all pitch in to create an environment where kids can thrive. It feels like everyone here understands that strong schools make a strong neighborhood. | citizenVoice PRESS Mei Wong
<!-- SELF-SCORE: question-answered=no; affected-citizen-shown=yes; sim-state-cited=yes -->
