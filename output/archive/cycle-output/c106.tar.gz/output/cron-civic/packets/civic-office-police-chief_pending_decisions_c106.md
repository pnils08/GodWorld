# Pending Decisions — Police Chief Rafael Montez — Cycle 106


## City This Cycle
The city stands at about 390,304 people; nearly everyone who wants work has it and the economy reads stable. The streets feel game this cycle.

**Evening texture:**
- **Famous people spotted:** Derek Obi, Jade Orion, Arturo Ramos
- **Restaurants:** **Eastlake Kitchen** (Eastlake), **Port Grind** (Grand Lake)
- **Fast food:** **SpeedyBurger** (Downtown)
- **Nightlife:** **Lakeside Whisper Bar** (Lake Merritt). Volume 4, vibe game-night, movement restricted. Weather impact 1.05.
- **City events:** West Oakland Neighborhood Stabilization Panel, Fruitvale Emergency Town Briefing, Lake Merritt Open-Air Book Market
- **Evening media TV:** **Crisis Desk**, **Slow Evenings**, **A's Prospect Report**, **The Julio Valencia (CL) Interview**
- **Evening media movies:** **Snowlight**, **Franchise**
- **Sports broadcast:** Oakland Sports Tonight - Playoff Special
- **Streaming trend:** breaking-news loop
- **Food trend:** Playoff tension dining - sports bar surge

**What happened around town:**
**Low-severity:**
- **HEALTH — crisis-spike — Laurel:** HEALTH event (impactScore 5)
- **GENERAL — texture — (no neighborhood):** flash choir
- **CIVIC — texture — (no neighborhood):** neighborhood grievance
- **FAITH — holy_day — Downtown:** Telegraph Presbyterian Fellowship observes Epiphany
- **FAITH — holy_day — Lake Merritt:** Cathedral of the Living Word observes Epiphany
- **FAITH — holy_day — Fruitvale:** St. Esperanza Parish observes Epiphany
- **FAITH — community_program — Downtown:** Telegraph Presbyterian Fellowship: job training workshop begins new session
- **FAITH — community_program — East Oakland:** Foothill Baptist Tabernacle: community health fair hosted

**Where the city is hurting (this cycle's worst signals):**
- Downtown: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
- Rockridge: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
- Grand Lake: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
- West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.

## What you did last cycle (the public remembers)
Based on elevated crime indices in East Oakland (1.17) and West Oakland (1.16), I've prioritized patrol realignment to enhance public safety coverage in these districts. Simultaneously, I'm forwarding the finalized OARI co-response operational matrix to ensure behavioral health calls receive appropriate behavioral health responses.

## Directive from Mara Vance, City Planning Director — answer it; silence is a choice you will be charged for
## Rafael Montez — Police Chief

- **Address:** Transmit the departmental patrol deployment adjustments for high-incident zones in East Oakland (CrimeIndex 1.11), West Oakland (CrimeIndex 1.10), and Downtown (CrimeIndex 1.10).
- **Why:** Elevated crime metrics persist across three major sectors in C106, requiring operational alignment between OPD sector patrols and OARI crisis response teams.
- **Acceptance:** A published public safety deployment briefing detailing patrol distribution and OARI co-response metrics.
- **Silence consequence:** Uncoordinated dispatch and patrol allocation across high-strain neighborhoods.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [High-Severity Incoherence Response] Rafael Montez — When service systems operate at cross purposes, residents pay the price—OPD is tightening operational coordination to reduce friction on the ground.
2. stated: [Patrol Deployment Realignment and OARI Co-Response Boundaries] Rafael Montez — Operational clarity between sworn patrol and alternative response teams prevents gaps in emergency coverage—that's not politics, it's dispatch protocol.
3. datawake: No public safety events requiring an official statement from this office occurred this cycle. OPD operations continue uninterrupted with standard deployments and response protocols.
4. stated: [Patrol Realignment & OARI Coordination] Rafael Montez — Public safety resources must align with neighborhood needs — that’s why we’re adjusting patrol patterns where call volume data shows the highest demand.
5. datawake: No public safety events requiring an official statement from this office occurred this cycle. OPD operations continue uninterrupted with standard deployments and response protocols.
6. stated: [OARI Pilot Expansion] Rafael Montez — Behavioral health crisis response requires careful operational integration — we're methodically refining the co-deployment model district by district.

Latest district pack on disk: output/cron-civic/packs/CHIEF-POLICE_c106.json
This week's lever from that pack: no move this cycle

## DECISION 1 — Engine review HIGH: incoherence

West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.
No city program currently answers this. Make a move this cycle — silence is a choice you will be charged for.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — The city's people this cycle — crisis and credit

Crisis: **San Antonio** — mood clearly upbeat, street trade slow, crime low. The people there are living this cycle whether City Hall speaks or not.
Success: **Temescal** — mood clearly upbeat, street trade busy. Somebody's work is paying off; say whose, or someone else will claim it.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of the city this cycle: who answers for San Antonio, and who gets the credit in Temescal?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
