# Pending Decisions — City Council District 8 Nina Chen — Cycle 106

## Live roster status (whip-read off THIS, not memory)
- D1 Denise Carter (OPP) — ACTIVE. Approval 76 (down 5 since last cycle)
- D2 Leonard Tran (IND) — ACTIVE. Approval 52 (down 2 since last cycle)
- D3 Rose Delgado (OPP) — ACTIVE. Approval 71 (down 5 since last cycle)
- D4 Ramon Vega (IND) — ACTIVE. Approval 51 (down 1 since last cycle)
- D5 Janae Rivers (OPP) — ACTIVE. Approval 76 (down 4 since last cycle)
- D6 Elliott Crane (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D7 Warren Ashford (CRC) — ACTIVE. Approval 45 (down 1 since last cycle)
- D8 Nina Chen (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D9 Terrence Mobley (OPP) — ACTIVE. Approval 51 (down 1 since last cycle)
- Full council: 9 active of 9 → a majority is 5.
Your approval stands at 51 — down 1 since last cycle.

## City This Cycle
- **Grand Lake** — mood clearly upbeat; street trade steady; crime low; flash choir; the mood there has slipped since last cycle.
- **Lake Merritt** — mood clearly upbeat; street trade steady; crime low; neighborhood grievance; the mood there has slipped since last cycle; Cathedral of the Living Word observes Epiphany.
- **Eastlake** — mood clearly upbeat; street trade slow; crime low.
- **Adams Point** — mood clearly upbeat; street trade slow; crime low.

## What you did last cycle (the public remembers)
I'm highlighting the proven success of community partnerships in Adams Point while addressing Lake Merritt's growing needs through a proposed liquor license moratorium. My focus remains on protecting neighborhood character through proper process and documentation.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [Oakland Youth Apprenticeship Pipeline Verification] Nina Chen — Apprenticeship backlogs are only truly cleared when administrative data and placement outcomes match on the record.
2. stated: [Lake Merritt Baseline and Public Process] Nina Chen — Lake Merritt's resilience belongs to the residents and merchant associations who stay engaged every single week, not to sudden City Hall gestures.
3. stated: [Grand Lake Commercial Vitality and Eastlake Economic Health] Nina Chen — Good governance requires documented intervention before neighborhood vitality slips further, not retroactive fixes after corridors empty.
4. stated: [District 8 Community Progress] Nina Chen — Adams Point proves what happens when we follow the process - real results through documented partnerships, not flashy promises.
5. stated: [Adams Point] Nina Chen — Adams Point's success didn't happen by accident—it was built on diligent local partnerships. --- stated: [Adams Point Success] Nina Chen — Adams Point's success didn't happen by accident—it was built on diligent local partnerships.

Latest district pack on disk: output/cron-civic/packs/COUNCIL-D8_c106.json
This week's lever from that pack: defend the district or go quiet

## DECISION 1 — Engine review HIGH: math imbalance

Grand Lake: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
No city program currently answers this. Make a move this cycle — silence is a choice you will be charged for.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Your constituents this cycle — crisis and credit

Crisis: **Eastlake** — mood clearly upbeat, street trade slow, crime low. The people there are living this cycle whether City Hall speaks or not.
Success: **Lake Merritt** — mood clearly upbeat, street trade steady. Somebody's work is paying off; say whose, or someone else will claim it.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for Eastlake, and who gets the credit in Lake Merritt?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
