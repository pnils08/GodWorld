# Pending Decisions — Health Center Project Director Bobby Chen-Ramirez — Cycle 106


## What you run
Temescal Community Health Center — Budget: $45M.

## City This Cycle
- **Temescal** — mood clearly upbeat; street trade busy; crime low.

## What you did last cycle (the public remembers)
With structural framing ahead of schedule, we're shifting focus to MEP rough-ins and interior build-out while maintaining seismic compliance. The second shift crew allows dusk pours to accelerate schedule without compromising OSHPD-3 standards.

## Directive from Mara Vance, City Planning Director — answer it; silence is a choice you will be charged for
## Bobby Chen-Ramirez — Health Center Project Director

- **Address:** File the inspection calendar for interior wall framing and mechanical, electrical, and plumbing (MEP) utility rough-ins for the Temescal Community Health Center (INIT-005).
- **Why:** With structural framing completed ahead of schedule in C105, tracker sequencing mandates interior framing and MEP inspections during C106 to maintain seismic compliance.
- **Acceptance:** A certified municipal inspection schedule for interior framing and rough-in utility sign-offs.
- **Silence consequence:** Building permit milestones lapse, risking construction slowdowns during interior build-out.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [construction_milestone] Bobby Chen-Ramirez — The pharmacist's bulletin board now shows conduit runs instead of lost cat posters. That's how you measure real community engagement.
2. datawake: Wall framing inspection starts Tuesday—we're checking every stud spacing before drywall goes up. The electricians are pulling wire on the second floor while plumbers test the first-floor risers. Two-shift crews keep us ahead of schedule without cutting corners. | action: On-site at dawn Tuesday to inspect first-wall framing with contractor foreman—verifying 16" on-center spacing and fireblocking before dryw
3. stated: [construction_progress] Bobby Chen-Ramirez — We're running two crews now—one at dawn, one at dusk—but I won't sign off on drywall until every conduit and duct meets spec. Temescal deserves systems that last.
4. datawake: Structural frame groundbreaking is ahead of schedule — caissons passed inspection, rebar placed per spec, and concrete pours complete. Temescal gets a building that lasts. | action: Inspecting structural frame installation with contractor foreman and structural engineer — verifying verticals, diagonals, and connections meet OSHPD-3 seismic requirements.
5. stated: [Temescal Community Health Center] Bobby Chen-Ramirez — We're not just building a health center—we're building trust. Every caisson, every shift, every dollar accounted for.
6. stated: [Temescal engagement] Bobby Chen-Ramirez — The pharmacist at 47th & Telegraph gets more questions about our crane schedule than I do. Starting next week, his bulletin board gets daily progress photos.

Latest district pack on disk: output/cron-civic/packs/PROJ-HEALTHCTR_c106.json
This week's lever from that pack: Interior wall framing and utility inspections

## DECISION 1 — Temescal Community Health Center — action due this cycle

Where it stands: C105: Structural frame completed ahead of schedule, MEP rough-ins advancing with second shift
Budget: $45M.
On the calendar: Interior wall framing and utility inspections — due THIS cycle.
The engine's own review flags this: Temescal: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Your constituents this cycle — crisis and credit

Crisis: **Temescal** — mood clearly upbeat, street trade busy, crime low. The people there are living this cycle whether City Hall speaks or not.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for Temescal?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
