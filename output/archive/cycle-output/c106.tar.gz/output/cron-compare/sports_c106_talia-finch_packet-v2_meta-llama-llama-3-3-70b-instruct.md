## A Night in West Oakland: Community Engagement with the Oaks Team
The sun had just set over West Oakland, casting a warm orange glow over the bustling streets. I walked into a local bar, the sound of laughter and chatter filling the air, and spotted Elio Perez, a server at a nearby restaurant, sipping on a drink. "I feel like the Oaks team is really trying to engage with our community, I see people getting excited about the games and it brings a sense of unity to our neighborhood, I'm happy to see that," he said, smiling as he took a sip of his drink.

As we talked, the TV behind the bar showed a replay of a recent Oaks game, and the patrons around us cheered and jeered in equal measure. Daniel Cloak, a bakery worker from the neighborhood, chimed in, "I feel like the Oaks team is trying to reach out to us, to the community, and it's good to see that. As someone who works in a bakery and lives in West Oakland, I think community engagement is important and I'm glad they're making an effort." The bartender, a friendly woman with a warm smile, nodded in agreement as she polished a glass and leaned in to listen.

Meanwhile, Irene Fay, a barista from a nearby coffee shop, sat at the end of the bar, looking a bit out of place. "I feel like community engagement with the Oaks team is something I've heard about, but I don't really know much about it. As a barista, I mostly just focus on my job and don't really get involved in that kind of thing," she said, looking around the bar with a curious expression. Darius Clark, a bakery worker and regular at the bar, overheard our conversation and added, "I feel like the community is pretty supportive of the Oaks team, I see people around here talking about them and it seems like they're trying to engage with us more."

As the night wore on, the conversation turned to the question of what would decide the Oaks' success this season. Elio leaned in, his eyes sparkling with enthusiasm, and the others nodded in agreement, continuing the discussion, with each person sharing their thoughts and opinions.

## INTAKE
NAMES: Elio Perez | quoted-source
NAMES: Daniel Cloak | quoted-source
NAMES: Irene Fay | quoted-source
NAMES: Darius Clark | quoted-source
STORYLINE: west-oakland-elio-perez-ripple | opened
HOOD: West Oakland
CLAIM: I feel like the Oaks team is really trying to engage with our community, I see people getting excited about the games and it brings a sense of unity to our neighborhood, I'm happy to see that | citizenVoice PRESS Elio Perez
<!-- SELF-SCORE: question-answered=no; affected-citizen-shown=yes; sim-state-cited=yes -->
