# STORY — civic c106 — Angela Reyes

## §1 ASSIGNMENT
- ANGLE (assigned by the editor — fixed): Rockridge has the strongest school record on the table (index 9) — the students and teachers who live it
- HOOK: 10 students and educators in Rockridge are on the ledger; the table says why their school reads the way it does.
- AFFECTED CITIZENS: Mei Wong (POP-01036); Maya Torres-Dillon (POP-00742); Rick Dillon (POP-00743); Rico Fister (POP-00305); Wiu Wiu (POP-00312); Gloria Liu (POP-00827); Simone Adesanya (POP-00287); Mateo Jilner (POP-01001); Mateo Wally (POP-01012); Salma Campbell (POP-01018)
- WHERE: Rockridge
- SOURCE: output/beats/Neighborhood_Demographics.jsonl @C106
- DESK APPROACH: Schools approach: this slice is the school table for every neighborhood — which school is doing well is answerable from the quality index — and the students and teachers on the ledger in the lead neighborhood. Warm, precise. Never invent a named student or teacher; a score trend is colour unless it is on this table. Facts on this slice: the names, places, roles and numbers listed. Those are real; do not invent people or places. Everything else about this beat — what it looks like, who is there, what they want and hate — is yours to paint.

## §2 THE REPORTER'S PLAN (wake 1, their own voice)
Rockridge stands out with the highest school quality index in Oakland at 9, boasting a 95% graduation rate and 78% college readiness. With 223 students and $15,000 in funding per student, the neighborhood’s educational success is notable. I want to explore what’s driving this excellence—focusing on the teachers, students, and programs that make Rockridge schools a model.
## §3 INTERVIEWS (wake 2 — real citizens, real quotes)
- Mei Wong (POP-01036): "As someone who works with kids in Rockridge, I’ve seen firsthand how much the community invests in education. It’s not just about funding—though that’s part of it—it’s the collective effort. Parents, teachers, and even local businesses all pitch in to create an environment where kids can thrive. It feels like everyone here understands that strong schools make a strong neighborhood."
- Maya Torres-Dillon (POP-00742): "As a teacher here, I think what makes Rockridge schools stand out is the combination of strong community support and dedicated educators. There's a real sense of shared responsibility—parents, teachers, and even local organizations like the Bay Conservation Alliance all pitch in. It's not just about funding, though that helps. It's about people showing up, consistently, for these kids."
- Simone Adesanya (POP-00287): "You know, what makes Rockridge schools special isn't any one thing you can point to—it's how this community wraps itself around these kids. It's teachers who've been here for decades knowing every student by name, parents who show up not just for their own child but for the whole class, and this unspoken expectation that we're all in this together. We don't just educate children here—we raise them."
- Rick Dillon (POP-00743): "I don't really think about it much, but I guess the teachers seem pretty good. My dad says it's because people here care about school and stuff. We just do our homework and play baseball after."

## §4 THE ARTICLE (wake 3)
- draft: output/cron-compare/staged/civic_c106_angela-reyes_packet-v2_deepseek-deepseek-chat.staged.md
- disposition: staged
- rhea: PASS
- self-score footer: present
- tool use: none

