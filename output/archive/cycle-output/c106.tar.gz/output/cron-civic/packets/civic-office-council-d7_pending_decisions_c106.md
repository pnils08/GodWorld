# Pending Decisions — City Council District 7 Warren Ashford — Cycle 106

## Live roster status (whip-read off THIS, not memory)
- D1 Denise Carter (OPP) — ACTIVE. Approval 76 (down 5 since last cycle)
- D2 Leonard Tran (IND) — ACTIVE. Approval 52 (down 2 since last cycle)
- D3 Rose Delgado (OPP) — ACTIVE. Approval 71 (down 5 since last cycle)
- D4 Ramon Vega (IND) — ACTIVE. Approval 51 (down 1 since last cycle)
- D5 Janae Rivers (OPP) — ACTIVE. Approval 76 (down 4 since last cycle)
- D6 Elliott Crane (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D7 Warren Ashford (CRC) — ACTIVE. Approval 45 (down 1 since last cycle)
- D8 Nina Chen (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D9 Terrence Mobley (OPP) — ACTIVE. Approval 51 (down 1 since last cycle)
- Full council: 9 active of 9 → a majority is 5.
Your approval stands at 45 — down 1 since last cycle.

## City This Cycle
- **Temescal** — mood clearly upbeat; street trade busy; crime low.
- **Rockridge** — mood clearly upbeat; street trade steady; crime low.
- **KONO** — mood clearly upbeat; street trade steady; crime low.

## What you did last cycle (the public remembers)
This cycle, I prioritized accountability in KONO and defending fiscal responsibility in Temescal. KONO requires transparent investment, and I pushed for detailed audits before committing city resources. In Temescal, I supported accelerating the health center construction but demanded oversight to ensure costs remain controlled.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [District 7 Economic Oversight and Service Allocation] Warren Ashford — Temescal is thriving because of District 7 discipline, and KONO will get targeted support only when the service gap audit is on my desk.
2. stated: [Rockridge Commercial Corridor Assessment] Warren Ashford — We do not solve quiet storefronts in Rockridge by throwing money into the dark—we demand data on merchant retention first.
3. stated: [Temescal Community Health Center Construction Milestone] Warren Ashford — The frame is up because District 7 demanded strict timelines, and we will keep the ledger balanced as utility inspections begin.
4. datawake: Temescal's sentiment sits above the city baseline at 0.51 and retail activity remains high, but property crime at 43 and violent crime at 33 remind us that commercial growth requires vigilant oversight. Defending District 7 means looking at the ledger honestly—we must ensure public safety expenditures match the actual incident rates across Temescal and KONO before greenlighting new allocations. | action: Au
5. stated: [Temescal Community Health Center] Warren Ashford — Temescal’s health center is happening—this spring, not next year. Because when you’re drilling foundations, you don’t clock out at 5.
6. stated: [KONO Infrastructure Crisis] Warren Ashford — KONO needs investment, but we need to see the receipts before we sign the check.

Latest district pack on disk: output/cron-civic/packs/COUNCIL-D7_c106.json
This week's lever from that pack: defend the district or go quiet

## DECISION 1 — Temescal Community Health Center — action due this cycle

Where it stands: C105: Structural frame completed ahead of schedule, MEP rough-ins advancing with second shift
Budget: $45M.
On the calendar: Interior wall framing and utility inspections — due THIS cycle.
The engine's own review flags this: Temescal: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Engine review HIGH: math imbalance

Rockridge: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
No city program currently answers this. Make a move this cycle — silence is a choice you will be charged for.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 3 — Your constituents this cycle — crisis and credit

Crisis: **KONO** — mood clearly upbeat, street trade steady, crime low. The people there are living this cycle whether City Hall speaks or not.
Success: **Temescal** — mood clearly upbeat, street trade busy. Somebody's work is paying off; say whose, or someone else will claim it.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for KONO, and who gets the credit in Temescal?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
