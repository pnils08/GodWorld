# Pending Decisions — City Council District 5 Janae Rivers — Cycle 106

## Live roster status (whip-read off THIS, not memory)
- D1 Denise Carter (OPP) — ACTIVE. Approval 76 (down 5 since last cycle)
- D2 Leonard Tran (IND) — ACTIVE. Approval 52 (down 2 since last cycle)
- D3 Rose Delgado (OPP) — ACTIVE. Approval 71 (down 5 since last cycle)
- D4 Ramon Vega (IND) — ACTIVE. Approval 51 (down 1 since last cycle)
- D5 Janae Rivers (OPP) — ACTIVE. Approval 76 (down 4 since last cycle)
- D6 Elliott Crane (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D7 Warren Ashford (CRC) — ACTIVE. Approval 45 (down 1 since last cycle)
- D8 Nina Chen (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D9 Terrence Mobley (OPP) — ACTIVE. Approval 51 (down 1 since last cycle)
- Full council: 9 active of 9 → a majority is 5.
Your approval stands at 76 — down 4 since last cycle.

## City This Cycle
- **East Oakland** — mood clearly upbeat; street trade slow; crime low; Foothill Baptist Tabernacle: community health fair hosted; the mood there has slipped since last cycle.
- **Baylight District** — mood clearly upbeat; street trade struggling; crime low.

## What you did last cycle (the public remembers)
East Oakland’s safety demands action, not audits. The youth pipeline must center our neighborhoods. Engine incoherence requires community-led solutions. Baylight’s slow streets aren’t city wins—they’re people’s victories.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [District 5 constituent accountability] Janae Rivers — Baylight's slow streets aren't city wins—they're people's victories. East Oakland's peace isn't paperwork—it's people power we haven't unleashed yet.
2. stated: [Engine-flagged incoherence] Janae Rivers — Incoherence isn't a glitch—it's systemic neglect. I'm done naming the problem; I'm legislating the fix.
3. stated: [Oakland Youth Apprenticeship Pipeline] Janae Rivers — Backlog cleared means nothing if East Oakland youth are still last in line. I want intake targets for our district and a town hall here, not downtown, this cycle.
4. stated: [Oakland Alternative Response Initiative] Janae Rivers — East Oakland's crime index at 1.17—nearly double the city average—isn't a footnote, it's a five-alarm fire. I'll vote YES on expansion, but I'm filing a resolution this cycle to force East Oakland into the next wave with audits that actually move resources where the violence lives.
5. stated: [District 5 constituents] Janae Rivers — East Oakland’s peace isn’t paperwork—it’s people power. Baylight’s slow streets? That’s resilience, not planning.
6. stated: [Engine-flagged incoherence] Janae Rivers — Incoherence isn’t a glitch—it’s systemic neglect. Our neighborhoods write their own stories.

No district pack on disk for this office this cycle.

## DECISION 1 — Oakland Alternative Response Initiative — engine-flagged

Where it stands: C105: District 1 expansion launched; monthly reporting and audit framework in place.
Budget: $12.5M.
On the calendar: First expansion-district evaluation.
The engine's own review flags this: West Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: Fruitvale: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: East Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
The engine's own review flags this: West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Oakland Youth Apprenticeship Pipeline — action due this cycle

Where it stands: C105: Administrative order issued to clear backlog; intake processing targets mandated across agencies.
Budget: $12.5M.
On the calendar: Backlog processing completion + town hall — due THIS cycle.
The engine's own review flags this: West Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: Fruitvale: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: East Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
The engine's own review flags this: West Oakland, East Oakland, Fruitvale: improvement flagged at low severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 3 — Engine review HIGH: incoherence

West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.
No city program currently answers this. Make a move this cycle — silence is a choice you will be charged for.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 4 — Your constituents this cycle — crisis and credit

Crisis: **East Oakland** — mood clearly upbeat, street trade slow, crime low. The people there are living this cycle whether City Hall speaks or not.
Success: **Baylight District** — mood clearly upbeat, street trade struggling. Somebody's work is paying off; say whose, or someone else will claim it.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for East Oakland, and who gets the credit in Baylight District?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
