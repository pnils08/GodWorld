# Pending Decisions — City Council District 1 Denise Carter — Cycle 106

## Live roster status (whip-read off THIS, not memory)
- D1 Denise Carter (OPP) — ACTIVE. Approval 76 (down 5 since last cycle)
- D2 Leonard Tran (IND) — ACTIVE. Approval 52 (down 2 since last cycle)
- D3 Rose Delgado (OPP) — ACTIVE. Approval 71 (down 5 since last cycle)
- D4 Ramon Vega (IND) — ACTIVE. Approval 51 (down 1 since last cycle)
- D5 Janae Rivers (OPP) — ACTIVE. Approval 76 (down 4 since last cycle)
- D6 Elliott Crane (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D7 Warren Ashford (CRC) — ACTIVE. Approval 45 (down 1 since last cycle)
- D8 Nina Chen (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D9 Terrence Mobley (OPP) — ACTIVE. Approval 51 (down 1 since last cycle)
- Full council: 9 active of 9 → a majority is 5.
Your approval stands at 76 — down 5 since last cycle.

## City This Cycle
- **Brooklyn** — mood clearly upbeat; street trade slow; crime low.
- **West Oakland** — mood clearly upbeat; street trade slow; crime low.

## What you did last cycle (the public remembers)
Approved Month-six Stabilization Fund disbursements with urgency for vulnerable households, launched OARI in D1 while addressing incoherence flags, demanded Youth Pipeline backlog clearance, and directly confronted systemic gaps in West Oakland. Credit for Brooklyn's progress goes to community resilience, not City Hall.

## Directive from Mara Vance, City Planning Director — answer it; silence is a choice you will be charged for
## Denise Carter — City Council District 1

- **Address:** Present an economic recovery plan for West Oakland addressing depressed RetailVitality (5.01) and elevated CrimeIndex (1.10).
- **Why:** West Oakland holds the lowest retail vitality rank among active commercial zones in C106, coinciding with a 5-point approval drop (76 in C106) for the D1 office.
- **Acceptance:** A public policy statement or council memorandum outlining targeted commercial corridor relief and safety oversight for West Oakland.
- **Silence consequence:** Continued economic slide in West Oakland commercial corridors without targeted legislative intervention.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [District Constituents] Denise Carter — Brooklyn’s vitality comes from its people—not City Hall’s policies.
2. stated: [Systemic Incoherence] Denise Carter — High-severity incoherence isn’t a technicality—it’s a crisis.
3. stated: [Youth Apprenticeship Pipeline] Denise Carter — Every young person in this city deserves a shot, not a runaround.
4. stated: [Stabilization Fund] Denise Carter — Stability isn’t a waiting list—it’s a mandate. We’re hitting the streets this cycle to find the next households in need.
5. datawake: The West Oakland Stabilization Fund continues to make significant headway. This month’s disbursement is on track, targeting households in slipping blocks to ensure stability isn’t a waiting list. We’re seeing progress, but the momentum must be sustained. | signal: on track
6. stated: [District 1 Constituents] Denise Carter — Brooklyn’s vitality comes from its people—not City Hall’s policies. Let’s invest in the small businesses that kept lights on during lean years.

Latest district pack on disk: output/cron-civic/packs/COUNCIL-D1_c106.json
This week's lever from that pack: Month-seven disbursement review

## DECISION 1 — West Oakland Stabilization Fund — action due this cycle

Where it stands: C105: Month-six disbursement batch approved (12 households); canvass launched for slipping blocks.
Budget: $28M.
On the calendar: Month-seven disbursement review — due THIS cycle.
The engine's own review flags this: West Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Oakland Alternative Response Initiative — engine-flagged

Where it stands: C105: District 1 expansion launched; monthly reporting and audit framework in place.
Budget: $12.5M.
On the calendar: First expansion-district evaluation.
The engine's own review flags this: West Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: Fruitvale: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: East Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
The engine's own review flags this: West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 3 — Oakland Youth Apprenticeship Pipeline — action due this cycle

Where it stands: C105: Administrative order issued to clear backlog; intake processing targets mandated across agencies.
Budget: $12.5M.
On the calendar: Backlog processing completion + town hall — due THIS cycle.
The engine's own review flags this: West Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: Fruitvale: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.
The engine's own review flags this: East Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
The engine's own review flags this: West Oakland, East Oakland, Fruitvale: improvement flagged at low severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 4 — Engine review HIGH: incoherence

West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.
No city program currently answers this. Make a move this cycle — silence is a choice you will be charged for.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 5 — Your constituents this cycle — crisis and credit

Crisis: **Brooklyn** — mood clearly upbeat, street trade slow, crime low. The people there are living this cycle whether City Hall speaks or not.
Success: **West Oakland** — mood clearly upbeat, street trade slow. Somebody's work is paying off; say whose, or someone else will claim it.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for Brooklyn, and who gets the credit in West Oakland?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
