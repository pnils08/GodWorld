**Money Flows, But Questions Remain on West Oakland Stabilization Fund**  

Daniel Cloak wiped flour from his hands as the morning rush died down at Acorn Bakery. The West Oakland Stabilization Fund paperwork had been visible under the glass counter for weeks—a dog-eared flyer next to the day-old bread discount sign. "I’ve heard folks talking about the Stabilization Fund at the bakery," he said, nodding toward the regulars clustered near the espresso machine. "But it’s hard to tell where the money’s really going—it feels like we’re waiting for something solid to show up in the neighborhood."  

The fund, now marked *disbursement-active* in city ledgers, was pitched as a lifeline for storefronts like Acorn and the blocks radiating from Seventh Street. Yet three blocks over, Elio Perez reported the same open question from his diner shift: "I’ve heard people talking about the Stabilization Fund at work and on the block—everyone wants to know where the money’s going and if it’s really helping the neighborhood."  

No ledger yet details which businesses received funds first, or why. Darius Clark, another bakery worker, echoed the uncertainty: "Just hoping it helps."  

The unanswered question isn’t whether the money is moving—the tracker confirms it is—but who determines where it lands, and when the neighborhood sees the difference.

## INTAKE
NAMES: Elio Perez | quoted-source
NAMES: Daniel Cloak | quoted-source
NAMES: Darius Clark | mentioned
STORYLINE: west-oakland-elio-perez-initiative | advanced
HOOD: West Oakland
CLAIM: I’ve heard people talking about the Stabilization Fund at work and on the block—everyone wants to know where the money’s going and if it’s really helping the neighborhood. | citizenVoice PRESS Elio Perez
<!-- SELF-SCORE: question-answered=no; affected-citizen-shown=yes; sim-state-cited=yes -->
