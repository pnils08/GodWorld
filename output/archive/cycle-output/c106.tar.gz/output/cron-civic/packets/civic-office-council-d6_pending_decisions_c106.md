# Pending Decisions — City Council District 6 Elliott Crane — Cycle 106

## Live roster status (whip-read off THIS, not memory)
- D1 Denise Carter (OPP) — ACTIVE. Approval 76 (down 5 since last cycle)
- D2 Leonard Tran (IND) — ACTIVE. Approval 52 (down 2 since last cycle)
- D3 Rose Delgado (OPP) — ACTIVE. Approval 71 (down 5 since last cycle)
- D4 Ramon Vega (IND) — ACTIVE. Approval 51 (down 1 since last cycle)
- D5 Janae Rivers (OPP) — ACTIVE. Approval 76 (down 4 since last cycle)
- D6 Elliott Crane (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D7 Warren Ashford (CRC) — ACTIVE. Approval 45 (down 1 since last cycle)
- D8 Nina Chen (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D9 Terrence Mobley (OPP) — ACTIVE. Approval 51 (down 1 since last cycle)
- Full council: 9 active of 9 → a majority is 5.
Your approval stands at 51 — down 1 since last cycle.

## City This Cycle
- **Piedmont Ave** — mood clearly upbeat; street trade steady; crime low.

## What you did last cycle (the public remembers)
I stand with Piedmont Ave, ensuring our community continues to thrive with steady street trade and low crime. I’m convening a community safety walk to bridge the disconnect between statistics and lived experience.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [Oakland Youth Apprenticeship Pipeline Backlog Clearance] Elliott Crane — Clearing the backlog is basic municipal competence; the real test is sustained job placement.
2. stated: [West Oakland Stabilization Fund Month-Seven Disbursement] Elliott Crane — Targeted stabilization prevents displacement, provided every dollar is accounted for and delivered cleanly.
3. stated: [Piedmont Ave Commercial Vitality and Public Safety] Elliott Crane — Piedmont Avenue demonstrates that when public safety and local business stability align, the entire neighborhood prospers.
4. stated: [Community Safety] Elliott Crane — Numbers don’t tell the whole story—community trust does.
5. datawake: Piedmont Ave’s crime numbers are well below city averages, but sentiment gaps remain a concern. I’m convening a community safety walk to bridge that divide and ensure accountability on the ground.
6. stated: [Piedmont Ave — Community Engagement] Elliott Crane — Numbers don’t tell the whole story—community trust does. --- stated: [Development Accountability] Elliott Crane — Baylight District’s potential is immense, but only if we hold every step accountable.

No district pack on disk for this office this cycle.

## DECISION 1 — Your constituents this cycle — crisis and credit

Crisis: **Piedmont Ave** — mood clearly upbeat, street trade steady, crime low. The people there are living this cycle whether City Hall speaks or not.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for Piedmont Ave?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
