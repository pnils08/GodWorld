# Pending Decisions — City Council District 9 Terrence Mobley — Cycle 106

## Live roster status (whip-read off THIS, not memory)
- D1 Denise Carter (OPP) — ACTIVE. Approval 76 (down 5 since last cycle)
- D2 Leonard Tran (IND) — ACTIVE. Approval 52 (down 2 since last cycle)
- D3 Rose Delgado (OPP) — ACTIVE. Approval 71 (down 5 since last cycle)
- D4 Ramon Vega (IND) — ACTIVE. Approval 51 (down 1 since last cycle)
- D5 Janae Rivers (OPP) — ACTIVE. Approval 76 (down 4 since last cycle)
- D6 Elliott Crane (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D7 Warren Ashford (CRC) — ACTIVE. Approval 45 (down 1 since last cycle)
- D8 Nina Chen (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D9 Terrence Mobley (OPP) — ACTIVE. Approval 51 (down 1 since last cycle)
- Full council: 9 active of 9 → a majority is 5.
Your approval stands at 51 — down 1 since last cycle.

## City This Cycle
- **Uptown** — mood clearly upbeat; street trade steady; crime low.
- **Laurel** — mood clearly upbeat; street trade steady; crime low; health event in Laurel (HEALTH); the mood there has slipped since last cycle.

## What you did last cycle (the public remembers)
Voted YES on Baylight District Phase II to expand community-driven development. Highlighted Laurel's sustained progress as proof of focused investment and warned against letting Uptown's momentum overshadow smaller neighborhoods.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [Uptown success] Terrence Mobley — Uptown’s success isn’t just window dressing—it’s proof Oakland works.
2. stated: [Laurel stability] Terrence Mobley — Laurel’s progress isn’t legacy—it’s today’s work paying off.
3. datawake: Laurel's stability is hard-won—crime still below city averages with property at 28 and violent at 24 this cycle. Sentiment's holding at 0.36 while we keep housing pressure flat zero. This isn't luck—it's the result of staying focused on what works. I'm pushing back against any distraction from our momentum.
4. stated: [Baylight District Final Council Vote] Terrence Mobley — Uptown’s success isn’t just numbers—it’s the people who showed up to build it. Let’s honor that by ensuring Baylight’s next phase stays rooted in community ownership, not corporate handshakes.
5. stated: [District Priorities] Terrence Mobley — Laurel’s progress isn’t an accident—it’s the result of focused investment. We’re not slowing down now just because the Mayor’s spotlight moved on. --- stated: [Baylight District Final Council Vote] Terrence Mobley — Uptown's success isn't just numbers—it's proof that when we invest in our people, Oakland thrives. Let's keep building, not just here, but across the distri
6. datawake: "Laurel’s crime rates remain below city averages, with property crimes at 27 and violent crimes at 24 this cycle—well under the city’s 40.6 and 33.5. Sentiment stands steady at 0.49, and our housing pressure is flat zero. This isn’t a district in crisis—it’s one worth protecting. I’ll defend our momentum." By leveraging D9’s lower crime index (0.45 vs city 0.709) and stable metrics, Mobley opts to defend th

Latest district pack on disk: output/cron-civic/packs/COUNCIL-D9_c106.json
This week's lever from that pack: defend the district or go quiet

## DECISION 1 — Your constituents this cycle — crisis and credit

Crisis: **Laurel** — mood clearly upbeat, street trade steady, crime low. The people there are living this cycle whether City Hall speaks or not.
Success: **Uptown** — mood clearly upbeat, street trade steady. Somebody's work is paying off; say whose, or someone else will claim it.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for Laurel, and who gets the credit in Uptown?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
