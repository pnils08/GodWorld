# Civic Domain Slice — C105

- Shared source entries: 88
- Empty: no

## Carmen Delaine (`carmen-delaine`)
- Domain: civic-ledger
- Pulse: West Oakland Stabilization Fund | Status passed | phase disbursement-active
- Ref: Initiative_Tracker (InitiativeID INIT-001); snapshot: engine_audit_c105.json snapshots.Initiative_Tracker
- Candidates:
  - [55] West Oakland Stabilization Fund | Status passed | phase disbursement-active — Initiative_Tracker (InitiativeID INIT-001); snapshot: engine_audit_c105.json snapshots.Initiative_Tracker
  - [55] West Oakland Stabilization Fund | Month-six disbursement review + canvass launch C105 — Initiative_Tracker (InitiativeID INIT-001)
  - [55] Oakland Alternative Response Initiative | Status passed | phase implementation-active — Initiative_Tracker (InitiativeID INIT-002); snapshot: engine_audit_c105.json snapshots.Initiative_Tracker
  - [55] Oakland Alternative Response Initiative | First expansion-district launch (D1) C105 — Initiative_Tracker (InitiativeID INIT-002)
  - [55] Fruitvale Transit Hub Phase II — Visioning | Status visioning-complete | phase visioning — Initiative_Tracker (InitiativeID INIT-003); snapshot: engine_audit_c105.json snapshots.Initiative_Tracker
  - [55] Fruitvale Transit Hub Phase II — Visioning | Conduct first visioning session by January 15 C105 — Initiative_Tracker (InitiativeID INIT-003)

## Luis Navarro (`luis-navarro`)
- Domain: accountability-anomaly
- Pulse: repeating-event (medium) | Issue "strain" (+ 1 co-occurring tokens) recurred 4 cycles
- Ref: output/engine_audit_c105.json patterns[0]; evidence: Riley_Digest row(s)
- Candidates:
  - [80] repeating-event (medium) | Issue "strain" (+ 1 co-occurring tokens) recurred 4 cycles — output/engine_audit_c105.json patterns[0]; evidence: Riley_Digest row(s)
  - [80] coverage-gap (medium) | Domain "faith" produced 5 events this cycle with zero Tribune coverage last cycle — output/engine_audit_c105.json patterns[1]; evidence: WorldEvents_V3_Ledger row(s)
  - [80] production-imbalance (medium) | 22 neighborhoods report migration flow with zero economic events this cycle — output/engine_audit_c105.json patterns[2]; evidence: Neighborhood_Map row(s)
  - [80] improvement (low) | Initiative "Oakland Alternative Response Initiative" advanced: pilot_evaluation → implementation-active — output/engine_audit_c105.json patterns[3]; evidence: Initiative_Tracker row(s) 3
  - [80] improvement (low) | Initiative "Fruitvale Transit Hub Phase II — Visioning" advanced: visioning-complete → visioning — output/engine_audit_c105.json patterns[4]; evidence: Initiative_Tracker row(s) 4
  - [80] improvement (low) | Initiative "Baylight District — Final Council Vote" advanced: construction-planning → vote-scheduled — output/engine_audit_c105.json patterns[5]; evidence: Initiative_Tracker row(s) 6

## Trevor Shimizu (`trevor-shimizu`)
- Domain: infrastructure-transit
- Pulse: Fruitvale Transit Hub Phase II — Visioning advanced from visioning-complete to visioning; a milestone worth covering, not burying.
- Ref: output/engine_audit_c105.json patterns[4]; evidence: Initiative_Tracker row(s) 4
- Candidates:
  - [45] improvement (low) | Initiative "Fruitvale Transit Hub Phase II — Visioning" advanced: visioning-complete → visioning — output/engine_audit_c105.json patterns[4]; evidence: Initiative_Tracker row(s) 4
  - [45] improvement (low) | Initiative "Baylight District — Final Council Vote" advanced: construction-planning → vote-scheduled — output/engine_audit_c105.json patterns[5]; evidence: Initiative_Tracker row(s) 6
  - [45] Fruitvale Transit Hub Phase II — Visioning | Status visioning-complete | phase visioning — Initiative_Tracker (InitiativeID INIT-003); snapshot: engine_audit_c105.json snapshots.Initiative_Tracker
  - [45] Fruitvale Transit Hub Phase II — Visioning | Conduct first visioning session by January 15 C105 — Initiative_Tracker (InitiativeID INIT-003)
  - [45] Temescal Community Health Center | Status passed | phase construction-active — Initiative_Tracker (InitiativeID INIT-005); snapshot: engine_audit_c105.json snapshots.Initiative_Tracker
  - [45] retail/traffic/sentiment | Fruitvale Transit Hub Phase II — Visioning is visioning — ongoing transit effects in Fruitvale — Ripple_Ledger cycle 105 (CauseType initiative-implementation); rendered: world_summary_c105.md "## What Moved" > "### initiative-implementation"

## Dr. Lila Mezran (`lila-mezran`)
- Domain: health
- Pulse: Alisha Peña slept badly for a few nights running (Lake Merritt).
- Ref: output/world_summary_c105.md "## Who Lived It ### Health"
- Candidates:
  - [80] Alisha Peña — slept badly for a few nights running — output/world_summary_c105.md "## Who Lived It ### Health"
  - [80] Lemante Naruto — took time to recover from the flu — output/world_summary_c105.md "## Who Lived It ### Health"
  - [78] Yu Zen was hospitalized after a workplace accident. — output/world_summary_c105.md "## Chaos Events"
  - [65] Drew Lemon — dealt with a seasonal health concern — output/world_summary_c105.md "## Who Lived It ### Health"
  - [65] Genevieve Liu — dealt with a seasonal health concern — output/world_summary_c105.md "## Who Lived It ### Health"
  - [60] Adams Point health cluster (crisis-spike) | HEALTH event (impactScore 36) — output/world_summary_c105.md "## World Events"

## Noah Tan (`noah-tan`)
- Domain: environment
- Pulse: Drew Lemon — dealt with a seasonal health concern
- Ref: output/world_summary_c105.md ## Who Lived It
- Candidates:
  - [80] Drew Lemon — dealt with a seasonal health concern — output/world_summary_c105.md ## Who Lived It
  - [80] Genevieve Liu — dealt with a seasonal health concern — output/world_summary_c105.md ## Who Lived It
  - [80] Melton Neilon — relied on familiar social circles during cold period — output/world_summary_c105.md ## Who Lived It
  - [80] Marky Beal — limited social activity due to winter mood — output/world_summary_c105.md ## Who Lived It
  - [80] Rigo Ryno — helped the kids with homework at the kitchen table — output/world_summary_c105.md ## Who Lived It
  - [80] FAITH — holy_day — Downtown: Telegraph Presbyterian Fellowship observes Epiphany — output/world_summary_c105.md ## World Events

## Angela Reyes (`angela-reyes`)
- Domain: education-youth
- Pulse: improvement (low) | Initiative "Oakland Youth Apprenticeship Pipeline" advanced: implementation-active → pilot is active
- Ref: output/engine_audit_c105.json patterns[6]; evidence: Initiative_Tracker row(s) 7
- Candidates:
  - [45] improvement (low) | Initiative "Oakland Youth Apprenticeship Pipeline" advanced: implementation-active → pilot-active — output/engine_audit_c105.json patterns[6]; evidence: Initiative_Tracker row(s) 7
  - [45] Oakland Youth Apprenticeship Pipeline | Status announced | phase pilot-active — Initiative_Tracker (InitiativeID INIT-007); snapshot: engine_audit_c105.json snapshots.Initiative_Tracker
  - [45] Oakland Youth Apprenticeship Pipeline | Backlog processing completion + town hall C106 — Initiative_Tracker (InitiativeID INIT-007)
  - [45] sentiment/communityEngagement/retail | Oakland Youth Apprenticeship Pipeline is pilot-active — ongoing workforce effects in West Oakland, East Oakland, Fruitvale — Ripple_Ledger cycle 105 (CauseType initiative-implementation); rendered: world_summary_c105.md "## What Moved" > "### initiative-implementation"
  - [45] approval/district-sentiment | West Oakland Stabilization Fund sitting, nothing free (-2); Oakland Alternative Response Initiative sitting, nothing free (-2); Oakland Youth Apprenticeship Pipeline sitting, nothing free (-2); decay toward 50 (-1) — Ripple_Ledger cycle 105 (CauseType approval-shift); rendered: world_summary_c105.md "## What Moved" > "### approval-shift"
  - [45] approval/district-sentiment | Oakland Alternative Response Initiative sitting, nothing free (-2); Fruitvale Transit Hub Phase II — Visioning sitting, nothing free (-2); Oakland Youth Apprenticeship Pipeline sitting, nothing free (-2); decay toward 50 (-1) — Ripple_Ledger cycle 105 (CauseType approval-shift); rendered: world_summary_c105.md "## What Moved" > "### approval-shift"

_Generated by scripts/buildCivicDomainSlice.js — local records only._
