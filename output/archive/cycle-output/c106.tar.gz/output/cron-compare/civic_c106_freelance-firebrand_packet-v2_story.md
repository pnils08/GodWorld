# STORY — civic c106 — Jax Caldera

## §1 ASSIGNMENT
- ANGLE (assigned by the editor — fixed): The map says decay; the program roster does not answer it.
- AFFECTED CITIZENS: Michael Corliss — Photographer, KONO; Celeste Moon — singer, KONO; Merkin Jumper — Social Services Caseworker, Downtown; Eunice Marston — Senior Pastor / Faith Leader, Downtown; Tao Lee — Community Organizer, Downtown; Bruce Wright — Line Cook, Downtown; Amir Delia — Home Health Aide, Downtown; Kwame Jumper — student, Downtown; Russell Hayward — Insurance Adjuster, Laurel; Bianca Crook — Autonomous Systems Engineer, Lake Merritt
- WHERE: Downtown
- SOURCE: output/engine_audit_c106.json patterns[1]; evidence: Neighborhood_Map row(s) 2
- DESK APPROACH: Firebrand approach (sim stink-audit): do NOT open from the official timeline. Find what does not line up — metric vs claim, money vs outcome, boomtown copy vs decay, crisis with no owner. Write into the contradiction. Name who must answer. End on the unanswered question. Scene color is yours (weather, street, bar), including your own route through one or many bars, so long as it contradicts nothing on this slice. Do not invent a named business or institution that the sim has not supplied. Never invent careers for named people — RoleType lines are immutable. Never invent citizen names.

## §2 THE REPORTER'S PLAN (wake 1, their own voice)
I'm investigating the discrepancy between the perceived decay in Downtown and the lack of active initiatives to address it. I'll be talking to people in the area to understand the situation better.
## §3 INTERVIEWS (wake 2 — real citizens, real quotes)
- Eunice Marston (POP-00753): "I haven't really seen any significant changes or initiatives that address the concerns about Downtown decay, but I do see people from my community, like those coming out of Telegraph Presbyterian, going about their daily lives. As a faith leader, I try to stay focused on the people and their needs, rather than getting caught up in the broader issues."
- Merkin Jumper (POP-00688): "I've seen the way the neighborhood is, you know, the towers staying lit late and people always rushing to and from places like Telegraph Presbyterian and SpeedyBurger. It feels like there's a lot of activity, but at the same time, I've heard people talking about how Downtown is decaying. As someone who works with the community, I feel like I'm making a difference, but I also wish there were more initiatives to address the issues we're facing."
- Celeste Moon (POP-01061): "I haven't really thought about it, but I did hear Downtown was packed last night. That's all I know."

## §4 THE ARTICLE (wake 3)
- draft: output/cron-compare/staged/civic_c106_freelance-firebrand_packet-v2_anthropic-claude-sonnet-5.staged.md
- disposition: staged
- rhea: PASS
- self-score footer: present
- tool use: none

