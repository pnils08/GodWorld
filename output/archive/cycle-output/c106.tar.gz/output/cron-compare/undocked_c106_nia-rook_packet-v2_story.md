# STORY — undocked c106 — Nia Rook

## §1 ASSIGNMENT
- ANGLE (assigned by the editor — fixed): Recap Clarissa Dane's UNDOCKED episode — who's up, who's down, what the city argues about tomorrow. Facts: credits unsettled, systems Sol, combat 0, mishaps 0, magnitude 3/5. Standings: Clarissa Dane leads the board — rank #1, 3 cycle(s) led, current streak 3.
- AFFECTED CITIZENS: Clarissa Dane — UNDOCKED cast pilot
- WHERE: Fruitvale
- SOURCE: undocked:undocked-pop00143-Y3C2-e2
- DESK APPROACH: Recap approach (UNDOCKED show beat): open on the CITY watching, not the cockpit. Pick 1-2 bag modes and hold them. The typed episode facts are the spine — credits, systems, combat, mishaps, magnitude — but lead with what it MEANS for who's up and who's down, never with the numbers. The pilot's packet interview is the only place their voice comes from. End on the one sentence the hallway will argue about tomorrow. This is the desk that's allowed to have fun.

## §2 THE REPORTER'S PLAN (wake 1, their own voice)
I'll be looking into how Clarissa Dane's recent UNDOCKED episode has affected her standing, and what the city is arguing about now
## §3 INTERVIEWS (wake 2 — real citizens, real quotes)
- Clarissa Dane (POP-00143): "I've been feeling like I'm in a bit of a push lately, trying to make a difference in Fruitvale as a District Attorney. It's been on my mind, how I can contribute to the positive impact I see in the community. I'm driven to do what's right for the people here, and I'm committed to making that happen."
- Rick Walker (POP-00198): "I've heard people talking about Clarissa Dane's episode and how it's affected her, but to be honest, I don't really know what to make of it - as a line cook and a resident of Fruitvale, I try to stay focused on my community and my family."
- Rafael Pilgrim (POP-00644): "I've seen how people around here in Fruitvale talk about Clarissa Dane's situation, and it seems like it's had a big impact on her lead, whatever that means for her."
- Tomas Renteria (POP-00744): "I've seen how people around here in Fruitvale are still talking about Clarissa Dane's episode and how it's affecting her, it's like the whole neighborhood is waiting to see what happens next with her lead."

## §4 THE ARTICLE (wake 3)
- draft: output/cron-compare/staged/undocked_c106_nia-rook_packet-v2_meta-llama-llama-3-3-70b-instruct.staged-2318.md
- disposition: staged
- rhea: PASS
- self-score footer: present
- tool use: none

