# STORY — civic c106 — Dr. Lila Mezran

## §1 ASSIGNMENT
- ANGLE (assigned by the editor — fixed): Chinatown carries the most sick residents (125) | 5 named on the hospital and cause records
- HOOK: Yu Zen is one of 5 residents on the record this cycle; Chinatown carries the most illness.
- AFFECTED CITIZENS: Yu Zen (POP-00194); Maurice Franklin (POP-00801); Marcus Osei (POP-00036); Elliott Crane (POP-00044); Ariana Lee (POP-00168)
- WHERE: Chinatown
- SOURCE: output/beats/Neighborhood_Demographics.jsonl Sick @C106 + Hospital_Ledger.jsonl + Health_Cause_Queue.jsonl
- DESK APPROACH: Health approach: this slice is the illness count by neighborhood and every resident named on the hospital and cause records this cycle. Clinical calm, human cost, no diagnosis beyond what the record says. When the named rows are few, write the neighborhood, not a ward. Facts on this slice: the names, places, roles and numbers listed. Those are real; do not invent people or places. Everything else about this beat — what it looks like, who is there, what they want and hate — is yours to paint.

## §2 THE REPORTER'S PLAN (wake 1, their own voice)
I'm focusing on Chinatown, which has the highest number of sick residents this cycle at 125. Among the named individuals, Marcus Osei, a City Council Member from Chinatown, is recovering from a car accident. His situation stands out because of his public role and the potential impact on the community. I want to explore how his recovery is being handled and what it means for Chinatown's residents.
## §3 INTERVIEWS (wake 2 — real citizens, real quotes)
- Yu Zen (POP-00194): "From where I'm lying in this hospital bed, all I hear are the nurses talking about how Chinatown's been hit hard this cycle. Marcus Osei's recovery? That's a bright spot in all this. When someone like him—someone known in the community—pulls through, it gives the rest of us hope. Chinatown's tight-knit; his recovery feels like a win for all of us fighting our own battles right now."
- Maurice Franklin (POP-00801): "I’ve heard bits and pieces about Marcus Osei’s recovery, mostly from neighbors talking. Chinatown’s been hit hard this season, and seeing someone like Marcus bounce back gives folks a little hope. It’s not just about him—it’s about the community feeling like they can pull through, too."

## §4 THE ARTICLE (wake 3)
- draft: output/cron-compare/staged/civic_c106_lila-mezran_packet-v2_deepseek-deepseek-chat.staged.md
- disposition: staged
- rhea: PASS
- self-score footer: present
- tool use: none

