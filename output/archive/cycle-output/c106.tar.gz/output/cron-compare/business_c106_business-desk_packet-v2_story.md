# STORY — business c106 — Jordan Velez

## §1 ASSIGNMENT
- ANGLE (assigned by the editor — fixed): West Oakland businesses: West Oakland Community Center, Oakmesh Systems, Civis Systems — the people who work there
- HOOK: Toby Lamont, Mutual Aid Network Organizer at West Oakland Community Center. 12 named workers at 3 named businesses in West Oakland on the ledger this cycle.
- AFFECTED CITIZENS: Toby Lamont (POP-00183); Brooklyn Nguyen (POP-00184); Simone Cleng (POP-00188); Leo Ling (POP-00342); Elijah Roberts (POP-00275); Enzo Walker (POP-00291); Dom Will (POP-00368); Jace Robinson (POP-00483); Sam Fazio (POP-00445); Catherine Santos (POP-00482); Elias  Varek (POP-00789); Maurice Franklin (POP-00801); Yolande McAllister (POP-00898); Andrew Cook (POP-00357); Yvonne Hayes (POP-01060); Dimmie Washington (POP-00511)
- WHERE: West Oakland
- SOURCE: output/beats/Business_Ledger.jsonl + Employment_Roster.jsonl @C106
- DESK APPROACH: Business desk approach: this slice is one neighborhood's businesses from the ledger and the people on the roster who work there. Open from a named business or a named worker on it — the block, the counter, the hiring board, what the owner is worried about. One claim about how the block is moving. Not civic process roundup. Not multi-voice business-desk average. Facts on this slice: the names, places, roles and numbers listed. Those are real; do not invent people or places. Everything else about this beat — what it looks like, who is there, what they want and hate — is yours to paint.

## §2 THE REPORTER'S PLAN (wake 1, their own voice)
I'm planning to focus on Toby Lamont at the West Oakland Community Center. His role as a Mutual Aid Network Organizer seems pivotal in understanding how the community services sector is evolving in West Oakland. I want to explore how the recent growth in employment at the center impacts the community aid networks and what challenges they face in scaling their operations.
## §3 INTERVIEWS (wake 2 — real citizens, real quotes)
- Toby Lamont (POP-00183): "Toby Lamont? Yeah, I know Toby—he's the kind of guy who doesn't just talk about community, he builds it. At the West Oakland Community Center, he's always moving, always connecting people. Doesn't matter if it's resources, skills, or just a listening ear—he makes sure folks get what they need. The man's got energy, you know? Like he's got three extra hours in his day the rest of us don't. But what really stands out? He doesn't just do the work—he makes sure people feel seen while he's doing it."
- Brooklyn Nguyen (POP-00184): "Toby Lamont? Yeah, I’ve seen him around the community center. He’s always got this energy, you know? Like he’s on a mission. I don’t know him personally, but you can tell he’s deeply invested in the neighborhood. He’s one of those people who makes you feel like West Oakland is in good hands."
- Simone Cleng (POP-00188): "Toby? Oh, he's got that quiet fire about him—the kind that keeps things running without needing credit. We've crossed paths at the Community Center a few times. He's the reason the mutual aid fridge stays stocked even when no one's looking. Doesn't talk much, but his hands are always doing the work."

## §4 THE ARTICLE (wake 3)
- draft: output/cron-compare/staged/business_c106_business-desk_packet-v2_deepseek-deepseek-chat.staged.md
- disposition: staged
- rhea: PASS
- self-score footer: present
- tool use: none

