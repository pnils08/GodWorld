PREWRITE:
- Reporter: Trevor Shimizu
- BagModes: [1 - Timestamp Incident, 7 - Maintenance Log Mind]
- AnchorFacts: 
  - 12th St Oakland City Center ridership 17,822 (+10,522 vs C105)
  - Total system ridership 85,857 (C105: 33,711)
- Claim: The transit system is handling nearly triple its prior ridership with no new capacity, relying entirely on worker adaptation.
- MissingData: Cause of ridership surge not verified in Packet.
- PriorFiling: None referenced in wall
```

# The Quiet Surge at 12th Street

Eleanor Rivera stood at the edge of the raised platform, one hand resting on the cold metal railing as the morning inbound train approached. The station manager had started her shift before sunrise, yet already the platforms at 12th Street Oakland City Center station hummed with activity—17,822 riders passing through that day, 10,522 more than last cycle. Rivera adjusted her headset slightly as she monitored the flow. 

"You know, it's been noticeable at 12th Street - more people coming through, more hustle in the station," Rivera said, her eyes tracking a group navigating the fare gates with practiced efficiency. "But what really sticks with me is how the team just... adjusts. No big announcements, just everyone doing their part to keep things moving smoothly."

Across Oakland's transit network, ridership figures told the same story—85,857 trips systemwide, more than double the previous cycle's 33,711. At MacArthur Station, ridership jumped by 7,113; at Fruitvale, 7,088 more riders passed through turnstiles. The increases showed no sign of straining schedules—on-time performance held steady or improved at nearly every station, with 12th Street's trains running 81% on schedule, a point better than before.

Down in the bus yards, Joel Wren wiped grease from his hands as he walked between the parked AC Transit coaches. "Those mechanics and drivers? They're the ones putting in the long hours to make sure everyone gets where they need to go," Wren said. Every maintenance bay buzzed with activity, each bus turned around faster than the dispatcher's clipboard could track. 

Back at 12th Street, janitor Jerald Jensen worked his mop in steady arcs across the tiles under the station clock. "I'm the one mopping up after the rush," Jensen said. His cleaning cart marked steady progress through the concourse as ridership numbers scrolled silently on the overhead display. The station hadn't added staff or hours—just the quiet work of those already on the roster.

Transit operator Coen Cartier guided his bus through the evening merge onto Telegraph Avenue. "The team's been working hard to keep things running smoothly, and it's paying off," Cartier said, though no policy memo or new initiative explained where all these new riders had come from. The system simply absorbed them—a 154% ridership increase with no new buses added, no additional train cars, just the same platforms and benches and fare gates handling triple the traffic.

At close of service, the station displays would reset, ready to count again tomorrow. The system had proven it could handle the surge. The question no display answered was how long adaptation could substitute for capacity.

## INTAKE
NAMES: Joel Wren | mentioned
NAMES: Jerald Jensen | mentioned
NAMES: Coen Cartier | mentioned
NAMES: Eleanor Rivera | quoted-source
STORYLINE: city-eleanor-rivera-beat-transit | opened
CLAIM: You know, it's been noticeable at 12th Street - more people coming through, more hustle in the station. But what really sticks with me is how the team just... adjusts. No big announcements, just everyone doing their part to keep things moving smoothly. It's not glamorous work, but when you see that many more people relying on the system, you realize how much depends on those quiet efforts. | citizenVoice PRESS Eleanor Rivera
<!-- SELF-SCORE: question-answered=no; affected-citizen-shown=yes; sim-state-cited=yes -->
