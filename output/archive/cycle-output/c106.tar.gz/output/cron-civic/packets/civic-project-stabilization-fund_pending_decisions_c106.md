# Pending Decisions — OEWD Program Director (Stabilization Fund) Marcus Webb — Cycle 106


## What you run
West Oakland Stabilization Fund — Budget: $28M.

## City This Cycle
- **West Oakland** — mood clearly upbeat; street trade slow; crime low.

## What you did last cycle (the public remembers)
We are advancing the Month-six disbursement batch to stabilize 12 additional households, bringing the total to 57 families protected. Simultaneously, we are launching a targeted canvass across West Oakland's slipping commercial blocks to accelerate outreach and ensure no eligible applicants are left behind. Every application is processed with precision to protect these futures.

## Directive from Mara Vance, City Planning Director — answer it; silence is a choice you will be charged for
## Marcus Webb — OEWD Program Director (Stabilization Fund)

- **Address:** Submit the Month-seven disbursement review and publish intake metrics from the commercial block canvass launched in C105.
- **Why:** Tracker milestones schedule the Month-seven disbursement review for C106, while West Oakland RetailVitality sits depressed at 5.01 and CrimeIndex remains high at 1.10.
- **Acceptance:** A filed Month-seven disbursement report specifying new households funded and canvass contact totals across West Oakland priority corridors.
- **Silence consequence:** Disruption in household grant flow and unverified field canvass coverage across slipping West Oakland blocks.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [West Oakland vitality] Marcus Webb — The fading storefronts tell the story before the displacement notices do—we're adjusting outreach now to match what the streets are showing us.
2. stated: [Month-seven disbursement execution] Marcus Webb — Sixty-nine households stabilized means sixty-nine West Oakland families who won't face displacement this month—and every case file meets compliance standards that will survive audit.
3. datawake: Month-seven disbursement review is audit-ready and walking to the Deputy Mayor's desk with zero compliance exceptions. Every approved application moves with certainty. | action: Walking the Month-seven disbursement authorization.
4. stated: [Month-six disbursement] Marcus Webb — Twelve more households have final approval for stabilization assistance—bringing us to fifty-seven families protected with zero compliance exceptions.
5. datawake: Twelve more households have final approval for stabilization assistance—bringing us to fifty-seven families protected with zero compliance exceptions. The Month-six batch is audit-ready and walking to the Deputy Mayor's desk today, and we're expanding outreach to slipping blocks identified this past cycle. Every approved application moves with certainty. | action: Walking the Month-six disbursement authoriz
6. stated: [West Oakland Stabilization Fund] Marcus Webb — Every applicant who walks through our door gets two things: the truth about the timeline, and the certainty that their case won’t get lost.

Latest district pack on disk: output/cron-civic/packs/PROJ-STABFUND_c106.json
This week's lever from that pack: Month-seven disbursement review

## DECISION 1 — West Oakland Stabilization Fund — action due this cycle

Where it stands: C105: Month-six disbursement batch approved (12 households); canvass launched for slipping blocks.
Budget: $28M.
On the calendar: Month-seven disbursement review — due THIS cycle.
The engine's own review flags this: West Oakland: daily life is visibly declining — the mood is slipping, storefronts are quieter — and no city program is currently pointed at it.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Your constituents this cycle — crisis and credit

Crisis: **West Oakland** — mood clearly upbeat, street trade slow, crime low. The people there are living this cycle whether City Hall speaks or not.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for West Oakland?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
