# Pending Decisions — OPP bloc (Carter D1, Delgado D3, Rivers D5, Mobley D9) — Cycle 103

## Live roster status (whip-read off THIS, not memory)
- D1 Denise Carter (OPP) — ACTIVE. Approval 95 (holding)
- D2 Leonard Tran (IND) — ACTIVE. Approval 58 (holding)
- D3 Rose Delgado (OPP) — ACTIVE. Approval 90 (holding)
- D4 Ramon Vega (IND) — ACTIVE. Approval 54 (holding)
- D5 Janae Rivers (OPP) — ACTIVE. Approval 90 (holding)
- D6 Elliott Crane (CRC) — ACTIVE. Approval 54 (holding)
- D7 Warren Ashford (CRC) — ACTIVE. Approval 48 (holding)
- D8 Nina Chen (CRC) — ACTIVE. Approval 54 (holding)
- D9 Terrence Mobley (OPP) — ACTIVE. Approval 54 (holding)
- Full council: 9 active of 9 → a majority is 5.

## City This Cycle
- **West Oakland** — mood clearly upbeat; street trade steady; crime low; New Covenant Pentecostal Assembly observes Christmas.
- **Brooklyn** — mood clearly upbeat; street trade steady; crime low.
- **Fruitvale** — mood clearly upbeat; street trade busy; crime low; St. Esperanza Parish observes Advent and Christmas.
- **San Antonio** — mood clearly upbeat; street trade slow; crime low.
- **East Oakland** — mood clearly upbeat; street trade steady; crime low; Foothill Baptist Tabernacle observes Christmas.
- **Baylight District** — mood clearly upbeat; street trade slow; crime low.
- **Uptown** — mood clearly upbeat; street trade busy; crime low; athlete sighting; stalled bus.
- **Laurel** — mood clearly upbeat; street trade busy; crime low; minor fender-bender.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [Baylight District Phase II Shortlist Credit Claim] Janae Rivers — Slow street trade in Baylight isn’t a ‘quiet victory’—it’s a symptom of a city that still prioritizes stadiums over storefronts. The real credit belongs to residents keeping their heads above water.
2. stated: [Neighborhood Coherence Task Force for West Oakland, Fruitvale, and East Oakland] Janae Rivers — Incoherence in our neighborhoods isn’t a mystery—it’s the legacy of policies that prioritized developers over residents. This task force must diagnose systemic disinvestment, not just symptoms.
3. stated: [Fruitvale Transit Hub Phase II Compliance Review] Janae Rivers — Phase II has been ‘visioning’ while Fruitvale’s small businesses bleed. We don’t need more studies—we need construction crews. Today’s compliance approval must trigger shovel-ready timelines.
4. stated: [West Oakland Stabilization Fund Month-Five Disbursement] Janae Rivers — Forty-five families helped isn’t a victory—it’s a down payment on what Oakland owes West Oakland. We’ll keep pushing until every displaced family has a home.
5. datawake: Baylight's slow street trade while crime stays low isn't a paradox—it's proof that safety without economic vitality is an incomplete victory. When neighborhoods like ours have 'flat moods' on paper but real people struggling to keep storefronts open, that's the quiet crisis we must treat with urgency. The same disinvestment that hollowed out West Oakland for decades is now playing out in slow motion here. |
6. stated: [Emergency Neighborhood Investment Hearing] Janae Rivers — When nine neighborhoods are burning, we don’t look away—we light a match under the bureaucracy.

Latest district pack on disk: output/cron-civic/packs/COUNCIL-D5_c103.json
This week's lever from that pack: D7 next-cycle report and community satisfaction survey

## DECISION 1 — West Oakland Stabilization Fund — action due this cycle

Where it stands: C102: Month-four disbursement batch approved (7 households), total disbursed: 45 of ~280.
On the calendar: Month-five disbursement batch review — due THIS cycle.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Oakland Alternative Response Initiative — action due this cycle

Where it stands: C102: D7 performance review confirms stabilization post-KONO crisis; monitoring continues.
On the calendar: D7 next-cycle report and community satisfaction survey — due THIS cycle.
The engine's own review flags this: West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 3 — Fruitvale Transit Hub Phase II — Visioning — action due this cycle

Where it stands: C102: Submitted pipeline exhaustion docs + stamped pedestrian-path redesign
On the calendar: Bureau review of compliance submissions — due THIS cycle.
The engine's own review flags this: INIT-003 has sat in the same stage for 9 cycles (Fruitvale). The ledger already says that — this cycle you move the phase or take a fail phase.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 4 — Engine review HIGH: stuck initiative

INIT-003 has sat in the same stage for 9 cycles (Fruitvale). The ledger already says that — this cycle you move the phase or take a fail phase.
This is a decision demand, not a briefing. Advance the phase or take a fail phase. Silence fails the apply gate.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 5 — Engine review HIGH: incoherence

West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.
No city program currently answers this. Make a move this cycle — silence is a choice you will be charged for.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 6 — Engine review HIGH: incoherence

West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.
No city program currently answers this. Make a move this cycle — silence is a choice you will be charged for.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 7 — Engine review HIGH: incoherence

West Oakland, Fruitvale, East Oakland: incoherence flagged at high severity.
No city program currently answers this. Make a move this cycle — silence is a choice you will be charged for.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 8 — Your constituents this cycle — crisis and credit

Crisis: **San Antonio** — mood clearly upbeat, street trade slow, crime low. The people there are living this cycle whether City Hall speaks or not.
Success: **Baylight District** — mood clearly upbeat, street trade slow. Somebody's work is paying off; say whose, or someone else will claim it.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for San Antonio, and who gets the credit in Baylight District?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S DECISIONS THIS CYCLE

- Oakland Youth Apprenticeship Pipeline — Recruitment and Intake Bottlenecks: approved — "Eighty-six applicants shouldn’t be stuck in paperwork. We’re cutting the red tape and getting these young people to work."
- West Oakland Stabilization Fund — Month-Five Disbursement: approved — "Forty-five families have their money. The next seven get theirs this week—no delays, no excuses."
- Oakland Alternative Response Initiative — D7 Community Satisfaction Survey: task_force_created — "Public safety isn’t just about response times—it’s about trust. We’re listening, and we’re acting."
- Fruitvale Transit Hub Phase II — Visioning Compliance Review: bureau_review_approved — "Fruitvale deserves a transit hub that works for the people who use it every day. We’re moving this forward."
- Temescal Community Health Center — HCAI First-Comments Resolution: phase_one_close_approved — "Temescal needs this health center now—not next year, not when the paperwork is perfect."
- Baylight District — Phase II Shortlist Publication: shortlist_published — "Baylight isn’t just a stadium—it’s the future of Oakland. We’re building it right."
- Neighborhood Coherence — West Oakland, Fruitvale, and East Oakland: task_force_announced — "When neighborhoods are hurting, we don’t look away—we build a plan."
- Celebrating Progress in Dimond and KONO: credit_attributed — "Dimond and KONO are proof that when we invest in neighborhoods, they thrive."

The Mayor has spoken. React in your own voice — support, oppose, or go your own way.

## MAYOR'S AGENDA THIS CYCLE

- Oakland Youth Apprenticeship Pipeline — Recruitment and Intake Adjustments: Directing OEWD to implement immediate intake adjustments for the Youth Apprenticeship Pipeline — "We can’t let bureaucracy stand in the way of opportunity for Oakland’s young people."
- West Oakland Stabilization Fund — Month-Five Disbursement Batch: Approving month-five disbursement batch for 8 households — "The families who qualified for this support shouldn’t have to wait another day."
- Oakland Alternative Response Initiative — D7 Community Satisfaction Survey: Directing OARI to expand community engagement in West Oakland, Fruitvale, and East Oakland — "Trust isn’t built in a day—it’s built through action, listening, and accountability."
- Fruitvale Transit Hub Phase II — Visioning Compliance Review: Directing Bureau of Planning to advance compliance review and schedule next visioning session — "Fruitvale deserves a transit hub that works for the people who use it every day—we’re not letting this stall."
- Temescal Community Health Center — HCAI First-Comments Resolution: Resolving HCAI first-comments window and closing Phase 1 — "Temescal needs this health center now—not next year, not when the paperwork is perfect."
- Baylight District — Phase II Shortlist Publication: Celebrating the publication of the Phase II shortlist — "Baylight isn’t just a stadium—it’s the future of Oakland, and we’re building it right."
- Neighborhood Coherence — KONO and Dimond: Acknowledging success in Dimond and committing to support KONO — "When neighborhoods thrive, Oakland thrives—and we’re investing in both."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
