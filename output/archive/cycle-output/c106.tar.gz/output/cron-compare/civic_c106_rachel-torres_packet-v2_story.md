# STORY — civic c106 — Sgt. Rachel Torres

## §1 ASSIGNMENT
- ANGLE (assigned by the editor — fixed): Downtown logged the most incidents (14) | 23 neighborhoods on the table — what the table says and who answers for it
- HOOK: Downtown leads the incident count; East Oakland waits longest for a response; 1 public-safety staff on the roster.
- AFFECTED CITIZENS: Vanessa Tran-Muñoz (POP-01021)
- WHERE: Downtown
- SOURCE: output/beats/Crime_Metrics.jsonl @C106
- DESK APPROACH: Public-safety approach: this slice is the crime table for every neighborhood — incidents, response time, clearance — and the public-safety staff on the roster. Measured, third person, incident structure and classification gaps. The numbers and the officials are real; the block, the call, the aftermath are yours. Facts on this slice: the names, places, roles and numbers listed. Those are real; do not invent people or places. Everything else about this beat — what it looks like, who is there, what they want and hate — is yours to paint.

## §2 THE REPORTER'S PLAN (wake 1, their own voice)
Downtown logged the most incidents this cycle, with 14 reported. The response time averaged 9.3 minutes, but clearance rates remain low at 15%. Property and violent crime indices are both elevated, signaling ongoing strain. Vanessa Tran-Muñoz, the OARI Program Director, is the only public-safety staff on the roster for Downtown. The numbers suggest a disconnect between incident volume and resource allocation. I want to dig into what’s behind these metrics—what’s happening on the ground, how OARI’s presence is shaping outcomes, and why clearance rates are so low despite the high volume of incidents.
## §3 INTERVIEWS (wake 2 — real citizens, real quotes)
- Jessie Hess (POP-00212): "I see the cops scrambling all the time down here - always in a hurry, never sticking around long enough to really fix anything. Vanessa's doing her best, but one person can't handle this whole neighborhood."

## §4 THE ARTICLE (wake 3)
- draft: output/cron-compare/flagged/civic_c106_rachel-torres_packet-v2_deepseek-deepseek-chat.md
- disposition: flagged
- rhea: flagged (1)
- self-score footer: present
- tool use: none

