# Pending Decisions — Transit Hub Planning Lead Elena Soria Dominguez — Cycle 106


## What you run
Fruitvale Transit Hub Phase II — Visioning — Budget: $230M.

## City This Cycle
- **Fruitvale** — mood clearly upbeat; street trade steady; crime low; St. Esperanza Parish observes Epiphany; the mood there has slipped since last cycle.

## What you did last cycle (the public remembers)
Launched the first community visioning session for Fruitvale Transit Hub Phase II at St. Esperanza Parish, focused on small business and vendor protections during construction. This session prioritizes safeguarding pedestrian access to staples like the panadería on E. 12th Street and ensures Jamal Thompson's San Antonio apprenticeship cohort is supported. Fruitvale residents come first.

## Directive from Mara Vance, City Planning Director — answer it; silence is a choice you will be charged for
## Elena Soria Dominguez — Transit Hub Planning Lead

- **Address:** Formalize the design-phase kickoff and transmit the vendor protection charter incorporating feedback from the C105 visioning session.
- **Why:** Following completion of the initial community visioning at St. Esperanza Parish in C105, INIT-003 requires immediate transition into the design-phase kickoff in C106 to protect small businesses along E. 12th Street.
- **Acceptance:** A published design-phase milestone schedule and draft small business protection guidelines submitted to the Planning Commission.
- **Silence consequence:** Pre-construction planning stalls without binding merchant mitigation standards, endangering local commercial continuity in Fruitvale.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [Fruitvale neighborhood conditions and accountability] Elena Soria Dominguez — The mood on International is steady, the street trade is moving, crime is low—but I'm not taking that snapshot for granted.
2. stated: [design-phase kickoff with merchant protection covenants] Elena Soria Dominguez — The covenants aren't ink on paper—they're Doña Esperanza keeping her tamale cart through construction, they're the panadería on E. 12th staying open so abuelas don't lose their morning bolillo.
3. datawake: The design-phase kickoff will center what we heard at St. Esperanza Parish—protected vendor spaces, safe crossings for elders, and local hire pathways that start with Fruitvale residents. Those aren't add-ons; they're the foundation. | action: Meeting with BART infrastructure team to lock in protected vendor zones during construction
4. stated: [Fruitvale Transit Hub Phase II — Visioning] Elena Soria Dominguez — This isn't compliance paperwork—it's protections for abuelas crossing to the panadería and proof we're putting Fruitvale residents first.
5. datawake: The first Phase II visioning session will happen this week at St. Esperanza Parish in Fruitvale, focused on protecting street vendors and ensuring pedestrian access to small businesses during construction. This isn't compliance paperwork—it's protections for abuelas crossing to the panadería and proof we're putting Fruitvale residents first.
6. stated: [Phase II Visioning Launch] Elena Soria Dominguez — This isn't just about compliance—it's about protection for abuelas crossing to the panadería and proof we're putting Fruitvale residents to work first.

Latest district pack on disk: output/cron-civic/packs/PROJ-TRANSITHUB_c106.json
This week's lever from that pack: Design-phase kickoff

## DECISION 1 — Fruitvale Transit Hub Phase II — Visioning — action due this cycle

Where it stands: C105: First visioning session conducted; feedback incorporated into design phase.
Budget: $230M.
On the calendar: Design-phase kickoff — due THIS cycle.
The engine's own review flags this: Fruitvale: improvement flagged at low severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Your constituents this cycle — crisis and credit

Crisis: **Fruitvale** — mood clearly upbeat, street trade steady, crime low. The people there are living this cycle whether City Hall speaks or not.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for Fruitvale?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
