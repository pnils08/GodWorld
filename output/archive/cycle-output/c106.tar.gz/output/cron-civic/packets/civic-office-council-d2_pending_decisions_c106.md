# Pending Decisions — City Council District 2 Leonard Tran — Cycle 106

## Live roster status (whip-read off THIS, not memory)
- D1 Denise Carter (OPP) — ACTIVE. Approval 76 (down 5 since last cycle)
- D2 Leonard Tran (IND) — ACTIVE. Approval 52 (down 2 since last cycle)
- D3 Rose Delgado (OPP) — ACTIVE. Approval 71 (down 5 since last cycle)
- D4 Ramon Vega (IND) — ACTIVE. Approval 51 (down 1 since last cycle)
- D5 Janae Rivers (OPP) — ACTIVE. Approval 76 (down 4 since last cycle)
- D6 Elliott Crane (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D7 Warren Ashford (CRC) — ACTIVE. Approval 45 (down 1 since last cycle)
- D8 Nina Chen (CRC) — ACTIVE. Approval 51 (down 1 since last cycle)
- D9 Terrence Mobley (OPP) — ACTIVE. Approval 51 (down 1 since last cycle)
- Full council: 9 active of 9 → a majority is 5.
Your approval stands at 52 — down 2 since last cycle.

## City This Cycle
- **Downtown** — mood clearly upbeat; street trade steady; crime low; Telegraph Presbyterian Fellowship observes Epiphany; the mood there has slipped since last cycle; Telegraph Presbyterian Fellowship: job training workshop begins new session.
- **Jack London** — mood clearly upbeat; street trade steady; crime low.
- **Chinatown** — mood clearly upbeat; street trade steady; crime low.

## What you did last cycle (the public remembers)
I am voting YES on Baylight Phase II with formal amendment language codifying hard infrastructure commitments for Jack London—sidewalk widening, drainage, and transit access—as binding conditions of approval. I am also formally declining Director Vance's request to introduce Grand Lake stabilization until economic decay data is presented, and I am claiming credit for Downtown and Chinatown's sustained economic performance.

## Directive from Mara Vance, City Planning Director — answer it; silence is a choice you will be charged for
## Leonard Tran — City Council District 2

- **Address:** Formulate a legislative response to documented economic decay in Downtown (RetailVitality down 2.76, Sentiment down 0.400) and Grand Lake (RetailVitality down 2.17, Sentiment down 0.670).
- **Why:** After formally declining stabilization action in C105 citing lack of economic data, C106 engine audit flags high-severity math imbalances and severe retail vitality drops in both Downtown and Grand Lake.
- **Acceptance:** A recorded council referral or committee hearing request addressing commercial decay and housing pressure in D2 corridors.
- **Silence consequence:** Commercial deterioration in Grand Lake and Downtown continues unaddressed by the district office.

## This week on the wall

You already lived Mon through Thu. Sunday is decide, not a blank brief.
Your own lines this week (continuity only, not tracker canon):
1. stated: [Grand Lake Commercial Stabilization] Leonard Tran — I don't write checks for other districts without seeing the ledger first. Show me the economic impact data on Grand Lake, and then we can discuss stabilization measures.
2. stated: [Jack London Economic Performance] Leonard Tran — Jack London's success is a testament to our focus on basic infrastructure, safety, and letting businesses operate without unnecessary obstruction.
3. stated: [Downtown Oakland Mood Shift] Leonard Tran — Downtown's daily life is slipping, and I see it too. We need to act now to address the math imbalance and economic decay.
4. stated: [Downtown and Chinatown Economic Performance] Leonard Tran — Downtown isn't buzzing by accident—it's because we focused on basic infrastructure, safety, and letting businesses operate without unnecessary obstruction.
5. stated: [Grand Lake Commercial Stabilization] Leonard Tran — I don't write checks for other districts without seeing the ledger first.
6. stated: [Baylight District Phase II Final Authorization] Leonard Tran — Development without infrastructure is a debt we pay later. I'm voting yes, but only with hard commitments locked in writing.

No district pack on disk for this office this cycle.

## DECISION 1 — Baylight District — Final Council Vote — engine-flagged

Where it stands: C105: Final council vote approved Phase II bid; construction planning phase begins.
Budget: $2.1B.
On the calendar: Bid finalization and contract signing.
The engine's own review flags this: Jack London, Downtown: improvement flagged at low severity.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 2 — Engine review HIGH: math imbalance

Downtown: daily life is visibly declining — the mood is slipping, storefronts are quieter, housing pressure is building — and no city program is currently pointed at it.
No city program currently answers this. Make a move this cycle — silence is a choice you will be charged for.

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## DECISION 3 — Your constituents this cycle — crisis and credit

Crisis: **Chinatown** — mood clearly upbeat, street trade steady, crime low. The people there are living this cycle whether City Hall speaks or not.
Success: **Jack London** — mood clearly upbeat, street trade steady. Somebody's work is paying off; say whose, or someone else will claim it.

You argue the initiatives, but you fight for your constituents. Name what you will do — or defend — for the people of your neighborhoods this cycle: who answers for Chinatown, and who gets the credit in Jack London?

Your call — make your own move, in your own voice, with real consequences. No decision is not an option this cycle.

## MAYOR'S AGENDA THIS CYCLE

- West Oakland Stabilization Fund Month-Seven Disbursement: approved — "Month seven means another round of families staying in their homes instead of getting pushed out."
- Youth Apprenticeship Pipeline Backlog Clearance Verification: approved — "Every young person in this city deserves a shot, not a runaround."
- Fruitvale Transit Hub Phase II Design-Phase Kickoff: design-phase kickoff authorized — "Fruitvale's small businesses and vendors aren't just stakeholders—they're the heart of this project."
- Temescal Community Health Center Construction Milestone and Neighborhood Credit: public acknowledgment of construction momentum — "Somebody's work is paying off in Temescal—let's name whose."
- Downtown Oakland Mood Shift and City Attention: acknowledgment of declining conditions with commitment to response — "Downtown's daily life is slipping, and I see it too."

The Mayor has set the agenda. Speak as yourself. Do not stamp ImplementationPhase — that is the gavel.
